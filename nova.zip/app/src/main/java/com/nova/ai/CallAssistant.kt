package com.nova.ai

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.net.Uri
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Call khulason ka chhota record (app ke andar, phone par hi). */
object CallLogStore {
    fun add(ctx: Context, dir: String, who: String, number: String, summary: String) {
        val p = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)
        val arr = try { JSONArray(p.getString("calls", "[]")) } catch (e: Exception) { JSONArray() }
        val o = JSONObject()
            .put("t", System.currentTimeMillis()).put("dir", dir)
            .put("who", who).put("num", number).put("sum", summary)
        val out = JSONArray()
        out.put(o)
        for (i in 0 until minOf(arr.length(), 29)) out.put(arr.getJSONObject(i))
        p.edit().putString("calls", out.toString()).apply()
    }

    fun list(ctx: Context): List<JSONObject> {
        val p = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)
        val arr = try { JSONArray(p.getString("calls", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }

    fun format(o: JSONObject): String {
        val t = SimpleDateFormat("dd MMM, hh:mm a", Locale.ENGLISH).format(Date(o.optLong("t")))
        val d = if (o.optString("dir") == "out") "Aap ne call ki" else "Call aayi"
        return "$t — $d (${o.optString("who")}): ${o.optString("sum")}"
    }
}

/**
 * Call Assistant: aane wali call 12 second (setting) baad uthata hai, poochta hai "kya kaam hai",
 * chhote kaam nipta kar call band karta hai aur khulasa deta hai. "Is ko call karo aur ye kaho" par
 * khud call kar ke baat karta hai.
 *
 * Android apps ko call ki awaaz seedhi nahi deta: NOVA speaker-phone par bolta hai aur mic se sunta hai.
 */
class CallAssistant(
    private val svc: Service,
    private val onStarted: () -> Unit,
    private val onEnded: () -> Unit
) {
    companion object {
        /** "X ko call karo aur usse ye kaho": service ko batao ke call ke baad baat ye karni hai. */
        fun requestOutgoing(ctx: Context, name: String, number: String, instruction: String) {
            ContextCompat.startForegroundService(
                ctx,
                Intent(ctx, WakeService::class.java)
                    .putExtra("out_name", name).putExtra("out_number", number).putExtra("out_instr", instruction)
            )
        }

        private const val CH = "nova_calls"
        private const val NOTE_ID = 21
    }

    private val handler = Handler(Looper.getMainLooper())
    private val prefs = svc.getSharedPreferences("nova", Context.MODE_PRIVATE)
    private val am = svc.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var registered = false
    private var ringing = false
    private var lastNumber: String? = null
    private var answerRunnable: Runnable? = null
    private var pendingOut: Triple<String, String, String>? = null
    private var pendingOutAt = 0L
    private var session: Session? = null

    fun isBusy() = session != null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val st = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)
            when (st) {
                TelephonyManager.EXTRA_STATE_RINGING -> onRinging(num)
                TelephonyManager.EXTRA_STATE_OFFHOOK -> onOffhook()
                TelephonyManager.EXTRA_STATE_IDLE -> onIdle()
            }
        }
    }

    fun register() {
        if (registered) return
        try {
            svc.registerReceiver(receiver, IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED))
            registered = true
        } catch (e: Exception) {
        }
        if (Build.VERSION.SDK_INT >= 26) {
            svc.getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CH, "NOVA call khulasa", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    fun unregister() {
        if (!registered) return
        try {
            svc.unregisterReceiver(receiver)
        } catch (e: Exception) {
        }
        registered = false
    }

    fun shutdown() {
        answerRunnable?.let { handler.removeCallbacks(it) }
        answerRunnable = null
        session?.finish(quiet = true)
        unregister()
    }

    fun prepareOutgoing(name: String, number: String, instruction: String) {
        pendingOut = Triple(name, number, instruction)
        pendingOutAt = System.currentTimeMillis()
    }

    // ---------- Phone ki halat ----------
    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(svc, p) == PackageManager.PERMISSION_GRANTED

    private fun incomingEnabled() =
        prefs.getBoolean("callAssist", false) && !(prefs.getString("secret", "") ?: "").isBlank()

    private fun onRinging(num: String?) {
        ringing = true
        if (!num.isNullOrBlank()) lastNumber = num
        if (session != null || answerRunnable != null || !incomingEnabled()) return
        val delay = prefs.getInt("callDelay", 12) * 1000L
        val r = Runnable { answerNow() }
        answerRunnable = r
        handler.postDelayed(r, delay)
    }

    private fun answerNow() {
        answerRunnable = null
        if (!ringing || session != null) return
        val number = lastNumber ?: ""
        val name = lookupName(number)
        if (prefs.getBoolean("callUnknownOnly", false) && name != null) return // contact hai: aap khud uthayein
        if (!granted(Manifest.permission.ANSWER_PHONE_CALLS) || Build.VERSION.SDK_INT < 26) return
        try {
            svc.getSystemService(TelecomManager::class.java).acceptRingingCall()
        } catch (e: Exception) {
            return
        }
        val who = name ?: number.ifBlank { "anjaan number" }
        handler.postDelayed({ begin("in", who, number, "") }, 900)
    }

    private fun onOffhook() {
        ringing = false
        answerRunnable?.let { handler.removeCallbacks(it) } // aap ne khud utha li
        answerRunnable = null
        val p = pendingOut
        if (p != null && session == null && System.currentTimeMillis() - pendingOutAt < 30_000) {
            pendingOut = null
            handler.postDelayed({ begin("out", p.first, p.second, p.third) }, 800)
        }
    }

    private fun onIdle() {
        ringing = false
        answerRunnable?.let { handler.removeCallbacks(it) }
        answerRunnable = null
        pendingOut = null
        session?.finish(quiet = false)
    }

    private fun lookupName(number: String): String? {
        if (number.isBlank() || !granted(Manifest.permission.READ_CONTACTS)) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number))
            svc.contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) {
            null
        }
    }

    private fun begin(mode: String, who: String, number: String, instr: String) {
        if (session != null) return
        onStarted()
        val s = Session(mode, who, number, instr)
        session = s
        s.start()
    }

    // ---------- Ek call ka poora silsila ----------
    private inner class Session(val mode: String, val who: String, val number: String, val instr: String) {
        val owner: String get() = (prefs.getString("owner", "") ?: "").ifBlank { "Boss" }
        val secret: String get() = prefs.getString("secret", "") ?: ""
        val history = ArrayList<Pair<String, String>>()
        val startedAt = System.currentTimeMillis()
        var mic: NovaMic? = null
        var tts: TextToSpeech? = null
        var ttsReady = false
        var ended = false
        var emptyRounds = 0
        var micDeadRounds = 0
        var apiFails = 0
        var opened = false
        var utt = 0
        val thenMap = HashMap<String, () -> Unit>()
        var prevSpeaker = false
        var prevVol = 0

        fun start() {
            configureAudio()
            tts = TextToSpeech(svc) { status ->
                handler.post {
                    if (ended) return@post
                    if (status != TextToSpeech.SUCCESS) {
                        finish(false)
                        return@post
                    }
                    tts?.setLanguage(Locale("en", "IN"))
                    tts?.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                    )
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) = spoken(utteranceId)

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) = spoken(utteranceId)
                    })
                    ttsReady = true
                    if (mode == "in") {
                        val g = "Assalam o Alaikum. Main NOVA hoon, $owner ka AI assistant. " +
                            "$owner abhi baat nahi kar sakte. Aap ko kya kaam hai?"
                        history.add("nova" to g)
                        speak(g) { listen() }
                    } else {
                        listen() // samne wala pehle "hello" bolega
                    }
                }
            }
            // Mic / TTS na chale to bhi call khatam hone par hisaab ho jaye.
            handler.postDelayed({ if (!ended && !ttsReady) finish(false) }, 8000)
        }

        private fun spoken(id: String?) {
            val key = id ?: return
            val then = thenMap.remove(key) ?: return
            handler.postDelayed({ if (!ended) then() }, 350)
        }

        fun speak(text: String, then: () -> Unit) {
            if (ended) return
            val t = tts
            if (!ttsReady || t == null) {
                then()
                return
            }
            val id = "c" + (++utt)
            thenMap[id] = then
            val r = t.speak(text.take(900), TextToSpeech.QUEUE_FLUSH, null, id)
            if (r != TextToSpeech.SUCCESS) {
                thenMap.remove(id)
                then()
            }
        }

        fun listen() {
            if (ended) return
            mic?.stop()
            if (System.currentTimeMillis() - startedAt > 4 * 60_000L) {
                wrapUp("Shukriya, main ab call band karta hoon. $owner ko paigham de dunga. Allah hafiz.")
                return
            }
            lateinit var m: NovaMic
            m = NovaMic(secret, true, object : NovaMic.Listener {
                override fun onLevel(level: Float) {}
                override fun onStatus(text: String) {}
                override fun onText(text: String) = emptyRound(m.lastPeak)
                override fun onAudio(wav: ByteArray) = process(wav)
                override fun onFailed(fatal: Boolean, message: String) {
                    wrapUp("Maaf kijiye, awaaz sunai nahi de rahi. $owner aap se baad mein baat karenge. Allah hafiz.")
                }
            }, raw = true)
            mic = m
            m.start()
        }

        private fun emptyRound(peak: Double) {
            if (ended) return
            emptyRounds++
            if (peak < 60) micDeadRounds++ else micDeadRounds = 0
            if (micDeadRounds >= 3) {
                history.add("nova" to "(mic ko call ki awaaz nahi mili)")
                wrapUp("Maaf kijiye, awaaz saaf nahi aa rahi. $owner aap se baad mein baat karenge. Allah hafiz.")
                return
            }
            if (mode == "in") {
                when {
                    emptyRounds >= 3 -> wrapUp("Koi jawab nahi mil raha. Main call band kar raha hoon. Allah hafiz.")
                    emptyRounds == 1 -> {
                        val q = "Hello, aap mujhe sun pa rahe hain?"
                        history.add("nova" to q)
                        speak(q) { listen() }
                    }
                    else -> listen()
                }
            } else {
                when {
                    emptyRounds >= 5 -> {
                        history.add("nova" to "(samne se koi jawab nahi aaya)")
                        hangup()
                    }
                    emptyRounds == 2 && !opened -> {
                        opened = true
                        turn(null, true)
                    }
                    else -> listen()
                }
            }
        }

        private fun process(wav: ByteArray) {
            if (ended) return
            turn(wav, false)
        }

        /** Backend se agla jumla maango (awaaz ya "pehla jumla"). */
        private fun turn(wav: ByteArray?, opening: Boolean) {
            val snapshot = history.toList()
            Thread {
                val r = NovaApi.callTurn(mode, owner, who, instr, snapshot, wav, opening, secret)
                handler.post {
                    if (ended) return@post
                    if (!r.ok) {
                        if (++apiFails >= 2) {
                            wrapUp("Maaf kijiye, abhi kuch masla hai. $owner aap se baad mein baat karenge. Allah hafiz.")
                        } else {
                            listen()
                        }
                        return@post
                    }
                    apiFails = 0
                    if (r.heard.isNotBlank()) {
                        history.add("caller" to r.heard)
                        emptyRounds = 0
                    }
                    if (r.say.isNotBlank()) {
                        history.add("nova" to r.say)
                        speak(r.say) { if (r.end) hangup() else listen() }
                    } else if (r.end) {
                        hangup()
                    } else if (r.heard.isBlank()) {
                        emptyRound(mic?.lastPeak ?: 100.0)
                    } else {
                        listen()
                    }
                }
            }.start()
        }

        private fun wrapUp(line: String) {
            mic?.stop()
            history.add("nova" to line)
            speak(line) { hangup() }
        }

        fun hangup() {
            mic?.stop()
            try {
                if (Build.VERSION.SDK_INT >= 28 && granted(Manifest.permission.ANSWER_PHONE_CALLS)) {
                    svc.getSystemService(TelecomManager::class.java).endCall()
                }
            } catch (e: Exception) {
            }
            handler.postDelayed({ if (!ended) finish(false) }, 3000)
        }

        fun finish(quiet: Boolean) {
            if (ended) return
            ended = true
            mic?.stop()
            try {
                tts?.stop()
                tts?.shutdown()
            } catch (e: Exception) {
            }
            restoreAudio()
            session = null
            val snap = history.toList()
            if (!quiet) {
                Thread {
                    val summary = NovaApi.callSummary(mode, owner, who, snap, secret)
                        ?: if (snap.size <= 1) "Koi baat nahi hui."
                        else snap.joinToString(" | ") { (w, t) -> (if (w == "nova") "NOVA" else "Samne wala") + ": " + t }
                            .take(400)
                    CallLogStore.add(svc, mode, who, number, summary)
                    handler.post { notifySummary(mode, who, summary) }
                }.start()
            }
            onEnded()
        }

        private fun configureAudio() {
            try {
                prevSpeaker = am.isSpeakerphoneOn
                prevVol = am.getStreamVolume(AudioManager.STREAM_VOICE_CALL)
                am.setStreamVolume(
                    AudioManager.STREAM_VOICE_CALL, am.getStreamMaxVolume(AudioManager.STREAM_VOICE_CALL), 0
                )
                if (Build.VERSION.SDK_INT >= 31) {
                    val dev = am.availableCommunicationDevices
                        .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    if (dev != null) am.setCommunicationDevice(dev) else am.isSpeakerphoneOn = true
                } else {
                    am.isSpeakerphoneOn = true
                }
            } catch (e: Exception) {
            }
        }

        private fun restoreAudio() {
            try {
                if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
                am.isSpeakerphoneOn = prevSpeaker
                am.setStreamVolume(AudioManager.STREAM_VOICE_CALL, prevVol, 0)
            } catch (e: Exception) {
            }
        }
    }

    private fun notifySummary(mode: String, who: String, summary: String) {
        val open = android.app.PendingIntent.getActivity(
            svc, 5, Intent(svc, MainActivity::class.java),
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (mode == "out") "Aap ki call: $who" else "Call aayi thi: $who"
        val n = NotificationCompat.Builder(svc, CH)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(title)
            .setContentText(summary)
            .setStyle(NotificationCompat.BigTextStyle().bigText(summary))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        svc.getSystemService(NotificationManager::class.java).notify(NOTE_ID + (System.currentTimeMillis() % 1000).toInt(), n)
    }
}
