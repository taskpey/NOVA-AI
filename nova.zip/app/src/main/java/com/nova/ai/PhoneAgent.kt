package com.nova.ai

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONObject

/**
 * Phone Agent: "TikTok kholo, profile mein jao..." jaise lambay kaam.
 * Har qadam par screen ki list backend (AI) ko jati hai, AI agla qadam batata hai (tap / type / scroll...),
 * NOVA wo karta hai, aur ye tab tak chalta hai jab tak kaam poora na ho.
 * Bhejna / delete / post / payment jaise qadam se pehle aapse poocha jata hai.
 */
class PhoneAgent(
    private val ctx: Context,
    private val secret: String,
    private val onStatus: (String) -> Unit,
    private val confirm: (String, (Boolean) -> Unit) -> Unit,
    private val onFinished: (Boolean, String) -> Unit
) {
    companion object {
        private const val MAX_STEPS = 30

        // In apps mein NOVA kaam nahi karta (bank / wallet / password manager).
        private val BLOCKED = listOf(
            "bank", "wallet", "jazzcash", "easypaisa", "upaisa", "sadapay", "nayapay", "paypal",
            "keepass", "bitwarden", "lastpass", "authenticator", "password", "1password"
        )

        private val APPS = setOf(
            "tiktok", "youtube", "instagram", "facebook", "whatsapp", "chrome", "google", "gallery",
            "snapchat", "twitter", "telegram", "gmail", "maps", "playstore", "settings", "files",
            "tik", "tok", "insta", "fb", "yt"
        )
        private val NEWS = setOf(
            "mosam", "weather", "news", "khabar", "khabrein", "khabren", "موسم", "خبر"
        )
        private val VERBS = setOf(
            "comment", "comments", "profile", "scroll", "like", "follow", "subscribe", "search",
            "padho", "dekho", "dikhao", "post", "upload", "download", "install"
        )
        private val CHATTY = setOf("bare", "baare", "explain", "samjhao", "matlab", "hota", "kyun", "kaise")

        /** Ye jumla phone chalane wala lamba kaam lagta hai? */
        fun looksLikeTask(words: List<String>): Boolean {
            if (words.isEmpty()) return false
            if (words.first() == "agent") return true
            val news = words.any { it in NEWS }
            val app = words.any { it in APPS }
            val verb = words.any { it in VERBS }
            val chatty = words.any { it in CHATTY }
            return news || (!chatty && app && words.size >= 4) || (!chatty && verb && words.size >= 5)
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private val history = ArrayList<String>()
    private val notes = ArrayList<String>()
    private var goal = ""
    private var step = 0

    @Volatile
    private var stopped = false
    private var failures = 0

    fun start(goal: String) {
        this.goal = goal.removePrefix("agent").trim()
        step = 0
        stopped = false
        failures = 0
        history.clear()
        notes.clear()
        next(400)
    }

    fun stop() {
        stopped = true
        handler.removeCallbacksAndMessages(null)
    }

    private fun finish(ok: Boolean, msg: String) {
        if (stopped) return
        stopped = true
        handler.removeCallbacksAndMessages(null)
        onFinished(ok, msg)
    }

    private fun next(delay: Long = 1100) {
        if (stopped) return
        if (step >= MAX_STEPS) {
            finish(false, "Boss, $MAX_STEPS qadam mein kaam poora nahi hua. Main yahin ruk gaya.")
            return
        }
        handler.postDelayed({ observe() }, delay)
    }

    private fun observe() {
        if (stopped) return
        val svc = NovaAccessibilityService.instance
        if (svc == null) {
            finish(false, "Boss, Accessibility band hai. ⚙ se NOVA AI ko on karein.")
            return
        }
        val snap = svc.snapshot()
        if (snap == null) {
            if (++failures > 4) finish(false, "Boss, screen padh nahi paya.") else next(900)
            return
        }
        val pkgLower = snap.pkg.lowercase()
        if (BLOCKED.any { pkgLower.contains(it) }) {
            finish(false, "Boss, ye app bank / password jaisi hai, is mein main kaam nahi karta.")
            return
        }
        step++
        onStatus("Qadam $step: soch raha hoon...")
        NovaApi.agent(
            goal, snap.pkg, snap.text, history.takeLast(10), notes.takeLast(10), step, secret
        ) { ok, action, err ->
            handler.post {
                if (stopped) return@post
                if (!ok || action == null) {
                    if (++failures > 2) finish(false, "Boss, AI se jawab nahi mila: $err")
                    else {
                        step--
                        next(1200)
                    }
                } else {
                    failures = 0
                    perform(action)
                }
            }
        }
    }

    private fun perform(a: JSONObject) {
        val type = a.optString("type")
        val reason = a.optString("reason").ifBlank { type }
        val note = a.optString("note")
        if (note.isNotBlank()) notes.add(note.take(300))

        if (type == "done") {
            finish(true, a.optString("message").ifBlank { "Boss, kaam ho gaya." })
            return
        }
        if (type == "fail") {
            finish(false, a.optString("message").ifBlank { "Boss, ye kaam main nahi kar paya." })
            return
        }
        if (type == "ask") {
            confirm(a.optString("message").ifBlank { "Boss, jari rakhun?" }) { yes ->
                history.add("step $step: user se poocha, jawab " + if (yes) "haan" else "nahi")
                if (yes) next(300) else finish(false, "Theek hai Boss, ruk gaya.")
            }
            return
        }
        if (a.optBoolean("risky", false)) {
            confirm("Boss, $reason. Karun?") { yes ->
                if (yes) execute(a, type, reason)
                else finish(false, "Theek hai Boss, ye qadam nahi kiya aur kaam rok diya.")
            }
            return
        }
        execute(a, type, reason)
    }

    private fun execute(a: JSONObject, type: String, reason: String) {
        if (stopped) return
        val svc = NovaAccessibilityService.instance
        if (svc == null) {
            finish(false, "Boss, Accessibility band ho gayi.")
            return
        }
        onStatus("Qadam $step: $reason")
        val idx = if (a.has("index")) a.optInt("index", -1) else -1
        val ok: Boolean = when (type) {
            "click" -> idx >= 0 && svc.clickIndex(idx)
            "type" -> {
                val typed = svc.typeText(if (idx >= 0) idx else null, a.optString("text"))
                if (typed && a.optBoolean("enter", false)) {
                    handler.postDelayed({ svc.imeEnter() }, 500)
                }
                typed
            }
            "enter" -> svc.imeEnter()
            "swipe", "scroll" -> svc.swipe(a.optString("direction", "up"))
            "back" -> svc.global(AccessibilityService.GLOBAL_ACTION_BACK)
            "home" -> svc.global(AccessibilityService.GLOBAL_ACTION_HOME)
            "open_app" -> {
                val r = PhoneActions.openByName(ctx, a.optString("app"))
                r != null && !r.contains("nahi mili")
            }
            "wait" -> true
            else -> false
        }
        history.add("step $step: $type " + (if (idx >= 0) "[$idx] " else "") + a.optString("text") +
            a.optString("app") + a.optString("direction") + if (ok) " (ho gaya)" else " (NAKAAM)")
        next(if (type == "open_app") 2200 else 1100)
    }
}
