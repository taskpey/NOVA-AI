package com.nova.ai

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Offline voice recognition (Vosk). Abhi English model; ek baar download hota hai. */
class OfflineVoice(private val ctx: Context) {

    companion object {
        const val MODEL_NAME = "vosk-model-small-en-us-0.15"
        const val MODEL_URL = "https://alphacephei.com/vosk/models/$MODEL_NAME.zip"
    }

    private var model: Model? = null
    private var rec: Recognizer? = null
    private var service: SpeechService? = null

    @Volatile
    private var delivered = false

    private fun root() = File(ctx.filesDir, "vosk")
    private fun modelDir() = File(root(), MODEL_NAME)

    fun isReady(): Boolean = File(modelDir(), "am").isDirectory

    fun download(onProgress: (Int) -> Unit, onDone: (Boolean, String) -> Unit) {
        Thread {
            try {
                root().mkdirs()
                val zipFile = File(ctx.cacheDir, "model.zip")
                val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                val total = conn.contentLength.toLong()
                var done = 0L
                var last = -1
                conn.inputStream.use { input ->
                    zipFile.outputStream().use { out ->
                        val buf = ByteArray(32 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) {
                                val p = (done * 100 / total).toInt()
                                if (p != last) {
                                    last = p
                                    onProgress(p)
                                }
                            }
                        }
                    }
                }
                conn.disconnect()
                onProgress(100)
                unzip(zipFile, root())
                zipFile.delete()
                if (isReady()) onDone(true, "") else onDone(false, "Model files sahi nahi mili")
            } catch (e: Exception) {
                onDone(false, e.message ?: "download fail")
            }
        }.start()
    }

    private fun unzip(zip: File, dest: File) {
        val destPath = dest.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val f = File(dest, entry.name)
                if (!f.canonicalPath.startsWith(destPath + File.separator)) {
                    throw SecurityException("Ghalat zip entry")
                }
                if (entry.isDirectory) {
                    f.mkdirs()
                } else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }

    fun start(onPart: (String) -> Unit, onFin: (String) -> Unit, onErr: (String) -> Unit) {
        Thread {
            try {
                if (service == null) {
                    val m = Model(modelDir().absolutePath)
                    val r = Recognizer(m, 16000.0f)
                    model = m
                    rec = r
                    service = SpeechService(r, 16000.0f)
                }
                rec?.reset()
                delivered = false

                fun deliver(t: String) {
                    if (delivered) return
                    delivered = true
                    service?.stop()
                    onFin(t)
                }

                val ok = service!!.startListening(object : RecognitionListener {
                    override fun onPartialResult(hypothesis: String?) {
                        val t = parse(hypothesis, "partial")
                        if (t.isNotBlank() && !delivered) onPart(t)
                    }

                    override fun onResult(hypothesis: String?) {
                        val t = parse(hypothesis, "text")
                        if (t.isNotBlank()) deliver(t)
                    }

                    override fun onFinalResult(hypothesis: String?) {
                        val t = parse(hypothesis, "text")
                        if (t.isNotBlank()) deliver(t)
                    }

                    override fun onError(exception: Exception?) {
                        if (!delivered) {
                            delivered = true
                            onErr(exception?.message ?: "unknown error")
                        }
                    }

                    override fun onTimeout() {
                        deliver("")
                    }
                }, 10000)
                if (!ok) onErr("mic start nahi hua")
            } catch (e: Exception) {
                onErr(e.message ?: "unknown error")
            }
        }.start()
    }

    private fun parse(json: String?, key: String): String =
        try {
            JSONObject(json ?: "{}").optString(key, "").trim()
        } catch (e: Exception) {
            ""
        }

    fun stop() {
        delivered = true
        try {
            service?.stop()
        } catch (e: Exception) {
        }
    }

    fun release() {
        try {
            service?.shutdown()
        } catch (e: Exception) {
        }
        try {
            model?.close()
        } catch (e: Exception) {
        }
        service = null
        rec = null
        model = null
    }

    fun delete() {
        release()
        modelDir().deleteRecursively()
    }
}
