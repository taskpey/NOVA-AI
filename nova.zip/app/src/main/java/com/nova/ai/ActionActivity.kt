package com.nova.ai

import android.app.Activity
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast

/** Bina screen wali activity: screenshots delete karne ki system ijazat (Android 11+) yahin se maangi jati hai. */
class ActionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        val uris: List<Uri> = intent.getParcelableArrayListExtra<Uri>("uris") ?: emptyList()
        if (uris.isEmpty()) {
            finish()
            return
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val pi = MediaStore.createDeleteRequest(contentResolver, uris)
                startIntentSenderForResult(pi.intentSender, 77, null, 0, 0, 0)
            } else {
                var n = 0
                for (u in uris) n += contentResolver.delete(u, null, null)
                Toast.makeText(this, "$n screenshot delete hue", Toast.LENGTH_SHORT).show()
                finish()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Delete nahi ho saka: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        finish()
    }
}
