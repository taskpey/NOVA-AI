package com.nova.ai

import java.util.Locale

/**
 * Urdu script -> Roman Urdu. Google ki Urdu voice recognition Urdu script deti hai, lekin NOVA ke
 * commands Roman Urdu / English par chalte hain. Pehle common alfaaz ki dictionary lagti hai
 * (open, call, whatsapp, torch...), baqi alfaaz harf-ba-harf Roman mein badle jate hain.
 */
object RomanUrdu {

    fun hasArabicScript(s: String): Boolean = s.any {
        it.code in 0x0600..0x06FF || it.code in 0x0750..0x077F ||
            it.code in 0xFB50..0xFDFF || it.code in 0xFE70..0xFEFF
    }

    private fun normalize(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when (c.code) {
                0x064A, 0x0649 -> sb.append('\u06CC') // ي ى -> ی
                0x0643 -> sb.append('\u06A9')         // ك -> ک
                0x0647 -> sb.append('\u06C1')         // ه -> ہ
                0x06D3 -> sb.append('\u06D2')         // ۓ -> ے
                0x0640, 0x200C, 0x200D, 0x200E, 0x200F -> {}
                in 0x064B..0x065F, 0x0670 -> {}      // zabar zer pesh etc.
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    // ---------- Dictionary ----------
    private fun parse(block: String): Map<String, String> =
        block.trimIndent().lines()
            .filter { it.contains('=') }
            .associate {
                val i = it.indexOf('=')
                normalize(it.substring(0, i).trim()) to it.substring(i + 1).trim()
            }

    private val PHRASES: List<Pair<String, String>> = parse(
        """
        السلام علیکم=assalam o alaikum
        واٹس ایپ=whatsapp
        واٹس اپ=whatsapp
        وٹس ایپ=whatsapp
        وہاٹس ایپ=whatsapp
        واٹسایپ=whatsapp
        وائی فائی=wifi
        ایس ایم ایس=sms
        یاد دلاؤ=yaad dilao
        یاد دلانا=yaad dilana
        یاد دلا دو=yaad dila do
        ویڈیو کال=video call
        فلیش لائٹ=flashlight
        فیس بک=facebook
        ٹک ٹاک=tiktok
        جی میل=gmail
        گوگل میپس=google maps
        شٹ ڈاؤن=shutdown
        بات سنو=baat suno
        اسکرین شاٹ=screenshot
        سکرین شاٹ=screenshot
        اسکرین شاٹس=screenshots
        اسکرین شات=screenshot
        ٹک ٹوک=tiktok
        ٹیک ٹاک=tiktok
        ڈاؤن لوڈ=download
        ڈاؤن لوڈز=downloads
        پلے سٹور=playstore
        پلے اسٹور=playstore
        """
    ).toList().sortedByDescending { it.first.length }

    private val DICT: Map<String, String> = parse(
        """
        نووا=nova
        نوا=nova
        نووہ=nova
        نوو=nova
        نووا=nova
        ہیلو=hello
        ہائے=hi
        ہائی=hi
        ہای=hi
        ہے=hai
        ہیں=hain
        ہوں=hoon
        ہو=ho
        ہوا=hua
        ہوئی=hui
        سلام=salam
        اوپن=open
        اوپین=open
        لانچ=launch
        کھولو=kholo
        کھولیں=kholen
        کھول=khol
        کھولیے=kholiye
        کھولئے=kholiye
        چلاؤ=chalao
        چلاو=chalao
        چلا=chala
        شروع=shuru
        کرو=karo
        کر=kar
        کریں=karen
        کردو=kar do
        دو=do
        دیں=dein
        دے=de
        دیجیے=dijiye
        دیجئے=dijiye
        لگاؤ=lagao
        لگاو=lagao
        لگا=laga
        لگانا=lagana
        بناؤ=banao
        رکھو=rakho
        بند=band
        روکو=roko
        رک=ruk
        ختم=khatam
        کاٹو=kaato
        آن=on
        آف=off
        اپ=up
        ڈاؤن=down
        اوپر=upar
        نیچے=neeche
        بڑھاؤ=barhao
        بڑھا=barha
        کم=kam
        گھٹاؤ=ghatao
        زیادہ=zyada
        تیز=tez
        دھیما=dheema
        فل=full
        میکس=max
        منٹ=minute
        منٹس=minutes
        مِنٹ=minute
        گھنٹہ=ghanta
        گھنٹے=ghante
        سیکنڈ=second
        سیکنڈز=seconds
        بعد=baad
        بجے=baje
        صبح=subah
        شام=shaam
        رات=raat
        دوپہر=dopahar
        ٹائم=time
        وقت=waqt
        تاریخ=tareekh
        دن=din
        آج=aaj
        کل=kal
        کیا=kya
        کون=kaun
        کیسے=kaise
        کیوں=kyun
        بتاؤ=batao
        بتا=bata
        بتائیں=batayen
        دکھاؤ=dikhao
        سناؤ=sunao
        سنو=suno
        سن=sun
        بات=baat
        باتیں=baatein
        پڑھو=padho
        پڑھ=padh
        بھیجو=bhejo
        بھیج=bhej
        بھیجنا=bhejna
        لکھو=likho
        بولو=bolo
        پیغام=paigham
        میسج=message
        میسیج=message
        ایس=s
        ٹیکسٹ=text
        کال=call
        کالز=calls
        فون=phone
        موبائل=mobile
        نمبر=number
        ڈائل=dial
        ملاؤ=milao
        کانٹیکٹ=contact
        کانٹیکٹس=contacts
        رابطہ=rabta
        تلاش=talash
        ڈھونڈو=dhoondo
        ڈھونڈ=dhoondh
        سرچ=search
        نوٹیفکیشن=notification
        نوٹیفکیشنز=notifications
        نوٹیفیکیشن=notification
        نیا=naya
        نئی=nayi
        آیا=aaya
        آئی=aayi
        آئے=aaye
        ٹارچ=torch
        فلیش=flash
        لائٹ=light
        الارم=alarm
        ٹائمر=timer
        ریمائنڈر=reminder
        یاد=yaad
        دلاؤ=dilao
        والیوم=volume
        آواز=awaaz
        برائٹنس=brightness
        روشنی=roshni
        لاک=lock
        اسکرین=screen
        سکرین=screen
        تالا=tala
        پاور=power
        مینو=menu
        ریسٹارٹ=restart
        ریبوٹ=reboot
        میوزک=music
        گانا=gana
        گانے=gane
        اگلا=agla
        پچھلا=pichla
        پلے=play
        پاز=pause
        اسٹاپ=stop
        نیکسٹ=next
        کیمرہ=camera
        کیمرا=camera
        گیلری=gallery
        سیٹنگ=setting
        سیٹنگز=settings
        سیٹنگس=settings
        ترتیبات=settings
        بلوٹوتھ=bluetooth
        لوکیشن=location
        بیٹری=battery
        چارج=charge
        ڈسپلے=display
        ساؤنڈ=sound
        ایپ=app
        ایپس=apps
        یوٹیوب=youtube
        کروم=chrome
        انسٹاگرام=instagram
        گوگل=google
        میپس=maps
        ہیلپ=help
        مدد=madad
        کمانڈ=command
        کو=ko
        کا=ka
        کی=ki
        کے=ke
        سے=se
        میں=mein
        پر=par
        پہ=pe
        اور=aur
        اینڈ=and
        پھر=phir
        یا=ya
        نہیں=nahi
        نہ=na
        مت=mat
        ہاں=haan
        جی=ji
        اوکے=ok
        ٹھیک=theek
        بالکل=bilkul
        شکریہ=shukriya
        تھینکس=thanks
        پلیز=please
        مجھے=mujhe
        میرا=mera
        میری=meri
        میرے=mere
        اپنا=apna
        اپنی=apni
        تم=tum
        آپ=aap
        سیٹ=set
        سیو=save
        فیورٹ=favorite
        دوست=dost
        کتنی=kitni
        کتنے=kitne
        کتنا=kitna
        ایک=ek
        تین=teen
        چار=char
        پانچ=paanch
        چھ=chhe
        سات=saat
        آٹھ=aath
        نو=nau
        دس=das
        گیارہ=gyarah
        بارہ=barah
        کس=kis
        نے=ne
        بنایا=banaya
        بنائی=banai
        بنانے=banane
        تمہیں=tumhein
        تمہارا=tumhara
        تمھارا=tumhara
        تمہارے=tumhare
        مالک=malik
        اونر=owner
        ڈویلپر=developer
        لاگ=log
        مس=miss
        مسڈ=missed
        ہوم=home
        بیک=back
        واپس=wapas
        سائلنٹ=silent
        وائبریٹ=vibrate
        میوٹ=mute
        ان میوٹ=unmute
        رستہ=rasta
        راستہ=rasta
        نیویگیٹ=navigate
        سکرین=screen
        سٹارٹ=start
        اسٹارٹ=start
        شروع=shuru
        پلس=plus
        مائنس=minus
        ملٹیپلائی=multiply
        ڈیوائیڈ=divide
        فیصد=percent
        سکہ=sikka
        کوائن=coin
        ڈائس=dice
        اسٹوریج=storage
        سٹوریج=storage
        کتنی=kitni
        بچی=bachi
        بچا=bacha
        خالی=khali
        ٹک ٹاک=tiktok
        ٹکٹاک=tiktok
        ڈیلیٹ=delete
        ڈاؤنلوڈ=download
        ڈاؤنلوڈز=downloads
        فولڈر=folder
        فولڈرز=folders
        فائل=file
        فائلز=files
        فائلیں=files
        فوٹو=photo
        فوٹوز=photos
        تصویر=photo
        تصاویر=photos
        پروفائل=profile
        کمنٹ=comment
        کمنٹس=comments
        ویڈیو=video
        ویڈیوز=videos
        موسم=mosam
        خبر=khabar
        خبریں=khabrein
        نیوز=news
        ہٹاؤ=hatao
        مٹاؤ=mitao
        سب=sab
        سارے=saare
        تمام=tamam
        ریسنٹ=recent
        نیو=new
        لیٹسٹ=latest
        پک=pic
        پکچر=picture
        بھیجیں=bhejen
        جاؤ=jao
        جا=ja
        جاکر=jakar
        اندر=andar
        آج=aaj
        بتاو=batao
        بتانا=batana
        کیسا=kaisa
        کیسی=kaisi
        ہے=hai
        """
    )

    private val NUMBERS = mapOf(
        "ek" to "1", "do" to "2", "teen" to "3", "char" to "4", "paanch" to "5", "chhe" to "6",
        "saat" to "7", "aath" to "8", "nau" to "9", "das" to "10", "gyarah" to "11", "barah" to "12"
    )
    private val UNITS = setOf(
        "baje", "minute", "minutes", "min", "ghanta", "ghante", "second", "seconds", "sec"
    )

    // ---------- Letters ----------
    private val LETTER = mapOf(
        'ب' to "b", 'پ' to "p", 'ت' to "t", 'ٹ' to "t", 'ث' to "s", 'ج' to "j", 'چ' to "ch",
        'ح' to "h", 'خ' to "kh", 'د' to "d", 'ڈ' to "d", 'ذ' to "z", 'ر' to "r", 'ڑ' to "r",
        'ز' to "z", 'ژ' to "zh", 'س' to "s", 'ش' to "sh", 'ص' to "s", 'ض' to "z", 'ط' to "t",
        'ظ' to "z", 'غ' to "gh", 'ف' to "f", 'ق' to "q", 'ک' to "k", 'گ' to "g", 'ل' to "l",
        'م' to "m", 'ن' to "n", 'ں' to "n"
    )

    private fun isVowelStr(s: String) = s.isNotEmpty() && s.last() in "aeiou"

    private fun letters(w: String): String {
        val sb = StringBuilder()
        var lastConsonant = false
        val n = w.length
        var i = 0
        while (i < n) {
            val c = w[i]
            val isLast = i == n - 1
            val piece: String
            var consonant = false
            when {
                c == '\u06BE' -> { // ھ  (aspirate: bh, kh, ph ...)
                    sb.append('h'); i++; continue
                }
                c == 'ا' || c == 'آ' -> piece = if (c == 'آ') "aa" else "a"
                c == 'ع' -> piece = if (i == 0) "a" else ""
                c == 'ئ' -> piece = "i"
                c == 'ء' -> piece = ""
                c == 'و' -> piece = if (i == 0) "w" else "o"
                c == 'ؤ' -> piece = "o"
                c == 'ی' -> piece = if (i == 0) "y" else "i"
                c == 'ے' -> piece = "e"
                c == 'ہ' || c == 'ۃ' -> {
                    piece = "h"; consonant = !isLast
                    if (isLast && lastConsonant) { sb.append('a'); lastConsonant = false; i++; continue }
                }
                LETTER.containsKey(c) -> { piece = LETTER[c]!!; consonant = true }
                c.isLetterOrDigit() -> piece = c.toString()
                else -> piece = ""
            }
            if (consonant && lastConsonant && !isLast) sb.append('a') // chhoti 'a' cluster todne ke liye
            sb.append(piece)
            if (piece.isNotEmpty()) lastConsonant = consonant
            i++
        }
        return sb.toString()
    }

    private fun clean(tok: String) = tok.trim { it in "۔،؟!.,?:;\"'()" }

    /** Urdu script ho to Roman banata hai; Roman/English text ko waise hi chhor deta hai. */
    fun toRoman(text: String): String {
        if (!hasArabicScript(text)) return text
        var s = normalize(text)
        for ((k, v) in PHRASES) s = s.replace(k, v)
        val out = ArrayList<String>()
        for (raw in s.split(Regex("\\s+"))) {
            val t = clean(raw)
            if (t.isEmpty()) continue
            out.add(
                if (!hasArabicScript(t)) t
                else DICT[t] ?: letters(t)
            )
        }
        // "saat baje" -> "7 baje"
        for (i in 0 until out.size - 1) {
            val num = NUMBERS[out[i]]
            if (num != null && out[i + 1] in UNITS) out[i] = num
        }
        return out.joinToString(" ")
    }

    // ---------- Fuzzy naam matching (contacts) ----------
    /** Vowels aur halki farq hata kar naam ka "dhancha": Kainat / Kainaat / کائنات sab "knt". */
    fun skeleton(s: String): String {
        var r = toRoman(s).lowercase(Locale.ROOT)
        r = r.replace("ch", "C").replace("sh", "S").replace("kh", "K").replace("gh", "G")
            .replace("ph", "f").replace("th", "t").replace("dh", "d").replace("bh", "b")
            .replace("jh", "j")
        val sb = StringBuilder()
        for (ch0 in r) {
            var ch = ch0
            if (!ch.isLetter()) continue
            if (ch == 'q' || ch == 'c') ch = 'k'
            if (ch == 'v') ch = 'w'
            if (ch in "aeiouyh") continue
            if (sb.isNotEmpty() && sb.last() == ch) continue
            sb.append(ch)
        }
        return sb.toString()
    }

    private fun distance(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** 0 = match nahi; 3 = sabse achha match. */
    fun matchScore(query: String, name: String): Int {
        val q = toRoman(query).lowercase(Locale.ROOT).trim()
        val nameLower = name.lowercase(Locale.ROOT)
        val nameRoman = toRoman(name).lowercase(Locale.ROOT)
        if (q.isEmpty()) return 0
        if (nameLower.contains(q) || nameRoman.contains(q)) return 3
        val qs = skeleton(q)
        if (qs.length < 2) return 0
        val words = nameRoman.split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }
        if (words.any { skeleton(it) == qs } || skeleton(nameRoman) == qs) return 2
        if (qs.length >= 3 && skeleton(nameRoman).contains(qs)) return 1
        if (qs.length >= 4 && words.any { distance(skeleton(it), qs) <= 1 }) return 1
        return 0
    }
}
