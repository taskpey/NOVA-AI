package com.nova.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

class WaveformView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private val n = 28
    private val levels = FloatArray(n)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val minH = 4f * resources.displayMetrics.density

    fun push(level: Float) {
        for (i in 0 until n - 1) levels[i] = levels[i + 1]
        levels[n - 1] = level.coerceIn(0f, 1f)
        invalidate()
    }

    fun clear() {
        levels.fill(0f)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        paint.shader = LinearGradient(
            0f, 0f, w.toFloat(), 0f,
            0xFF00B4FF.toInt(), 0xFF8A2BE2.toInt(), Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        val slot = width / n.toFloat()
        val bar = slot * 0.5f
        val cy = height / 2f
        for (i in 0 until n) {
            val h = max(minH, levels[i] * height)
            val x = i * slot + (slot - bar) / 2f
            rect.set(x, cy - h / 2f, x + bar, cy + h / 2f)
            c.drawRoundRect(rect, bar / 2f, bar / 2f, paint)
        }
    }
}
