package com.nova.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.util.Locale

/**
 * "Hi Nova" ke baad app khole baghair neeche gol animation (bubble) aata hai.
 * NOVA command sunta hai, kaam karta hai, phir poochta hai "Ab main jaoon?" aur ijazat milne par chala jata hai.
 */
class VoiceBubble(
    private val ctx: Context,
    private val modelProvider: () -> org.vosk.Model?,
    private val initialGoal: String?,
    private val onClosed: () -> Unit
) {
    private enum class State { COMMAND, ASK_LEAVE, AGENT, CONFIRM }

    private var agent: PhoneAgent? = null
    private var confirmCb: ((Boolean) -> Unit)? = null

    private val handler = Handler(Looper.getMainLooper())
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val prefs = ctx.getSharedPreferences("nova", Context.MODE_PRIVATE)

    private var root: LinearLayout? = null
    private var core: NovaCoreView? = null
    private var label: TextView? = null

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    @Volatile
    private var ttsBusy = false

    private var recognizer: SpeechRecognizer? = null
    private var vosk: SpeechService? = null
    private var voskRec: Recognizer? = null

    private var nmic: NovaMic? = null
    private var novaFails = 0

    private fun canNova(): Boolean =
        online() && novaFails < 2 && prefs.getBoolean("novamic", true) &&
            !(prefs.getString("secret", "") ?: "").isBlank()

    private var active = false
    private var listening = false
    private var state = State.COMMAND
    private var noSpeech = 0
    private var errors = 0
    private var cloudBusy = 0
    private var callStarted = false
    private val history = ArrayList<Msg>()

    private val comm = CommFlow(
        ctx,
        { t -> reply(t) },
        { perm, block -> ensure(perm, block) }
    ).also { c -> c.onCallStarted = { callStarted = true } }

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    // ---------- Start / stop ----------
    fun start(): Boolean {
        if (!Settings.canDrawOverlays(ctx)) return false
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) return false
        if (!createView()) return false
        active = true
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("en", "IN"))
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        ttsBusy = true
                    }

                    override fun onDone(utteranceId: String?) {
                        ttsBusy = false
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        ttsBusy = false
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        ttsBusy = false
                    }
                })
                ttsReady = true
            }
        }
        beep()
        val goal = initialGoal
        if (goal != null) handler.postDelayed({ handleSpoken(goal) }, 600)
        else handler.postDelayed({ listen() }, 350)
        return true
    }

    fun dismiss() {
        if (!active && root == null) return
        active = false
        agent?.stop()
        agent = null
        handler.removeCallbacksAndMessages(null)
        stopRecognizers()
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
        }
        tts = null
        val r = root
        root = null
        if (r != null) {
            r.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(180).withEndAction {
                try {
                    wm.removeView(r)
                } catch (e: Exception) {
                }
            }.start()
        }
        onClosed()
    }

    // ---------- UI ----------
    private fun createView(): Boolean {
        return try {
            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                alpha = 0f
                scaleX = 0.6f
                scaleY = 0.6f
            }
            val tv = TextView(ctx).apply {
                setTextColor(0xFFE6F6FF.toInt())
                textSize = 14f
                maxLines = 4
                maxWidth = dp(300)
                setPadding(dp(14), dp(8), dp(14), dp(8))
                background = GradientDrawable().apply {
                    setColor(0xE6101826.toInt())
                    cornerRadius = dp(18).toFloat()
                    setStroke(dp(1), 0xFF00B4FF.toInt())
                }
                text = "NOVA"
            }
            val orb = NovaCoreView(ctx).apply {
                setOnClickListener { dismiss() } // orb par tap = band
            }
            box.addView(
                tv,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(6) }
            )
            box.addView(orb, LinearLayout.LayoutParams(dp(96), dp(96)))

            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                y = dp(48)
            }
            wm.addView(box, lp)
            box.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
            root = box
            core = orb
            label = tv
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun show(text: String, isListening: Boolean? = null) {
        label?.text = if (text.length > 160) text.take(157) + "..." else text
        if (isListening != null) core?.listening = isListening
    }

    private fun beep() {
        try {
            val tg = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 120)
            handler.postDelayed({ tg.release() }, 400)
        } catch (e: Exception) {
        }
    }

    // ---------- Speaking ----------
    private fun reply(text: String) {
        if (!active) return
        show(text, false)
        if (ttsReady) {
            ttsBusy = true
            val r = tts?.speak(text.take(3900), TextToSpeech.QUEUE_ADD, null, "nova")
            if (r != TextToSpeech.SUCCESS) ttsBusy = false
        }
    }

    /** Bolna aur cloud jawab khatam hone ke baad `next` chalao. */
    private fun afterSpeech(waited: Int = 0, next: () -> Unit) {
        if (!active) return
        if ((ttsBusy || cloudBusy > 0) && waited < 60_000) {
            handler.postDelayed({ afterSpeech(waited + 300, next) }, 300)
        } else {
            next()
        }
    }

    // ---------- Listening ----------
    private fun online(): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        return caps != null &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    }

    private fun listen() {
        if (!active || listening) return
        listening = true
        show(
            when (state) {
                State.ASK_LEAVE -> "Ab main jaoon? (haan / nahi)"
                State.CONFIRM -> "Haan / nahi?"
                else -> "Sun raha hoon..."
            },
            true
        )
        when {
            canNova() -> startNova()
            online() && SpeechRecognizer.isRecognitionAvailable(ctx) -> startGoogle()
            else -> startVosk()
        }
    }

    private fun startNova() {
        nmic?.stop()
        val secret = prefs.getString("secret", "") ?: ""
        nmic = NovaMic(secret, prefs.getBoolean("urdu", true), object : NovaMic.Listener {
            override fun onLevel(level: Float) {}

            override fun onStatus(text: String) {
                if (listening) show(text, true)
            }

            override fun onText(text: String) {
                if (!active) return
                listening = false
                if (text.isNotBlank()) novaFails = 0
                handleSpoken(text)
            }

            override fun onFailed(fatal: Boolean, message: String) {
                if (!active) return
                listening = false
                novaFails += if (fatal) 2 else 1
                handler.postDelayed({ listen() }, 300)
            }
        }).also { it.start() }
    }

    private fun startGoogle() {
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(ctx).also {
                it.setRecognitionListener(googleListener)
            }
        } else {
            recognizer?.cancel()
        }
        val urdu = prefs.getBoolean("urdu", true)
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (urdu) "ur-PK" else "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
        }
        try {
            recognizer?.startListening(i)
        } catch (e: Exception) {
            startVosk()
        }
    }

    private val googleListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {
            errors = 0
        }

        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            if (!active) return
            listening = false
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> noSpeechRound()
                SpeechRecognizer.ERROR_SERVER_DISCONNECTED,
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT -> {
                    recognizer?.destroy()
                    recognizer = null
                    if (++errors < 3) handler.postDelayed({ listen() }, 300) else startVoskOrGiveUp()
                }
                else -> startVoskOrGiveUp() // permission / network masle par offline try
            }
        }

        override fun onResults(results: Bundle?) {
            if (!active) return
            listening = false
            val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.let { RomanUrdu.bestAlt(it) }
            handleSpoken(t ?: "")
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!t.isNullOrBlank()) show(RomanUrdu.toRoman(t))
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun startVoskOrGiveUp() {
        listening = false
        if (OfflineVoiceCheck.ready(ctx)) {
            listening = true
            startVosk()
        } else {
            reply("Boss, abhi awaaz sunai nahi de rahi. Baad mein dobara try karein.")
            afterSpeech { dismiss() }
        }
    }

    /** Offline (English) sunna: internet na ho ya Google service na chale tab. */
    private fun startVosk() {
        if (prefs.getBoolean("urdu", true)) {
            // Offline model sirf English samajhta hai: Urdu par ghalat jumle banata hai.
            listening = false
            reply("Boss, Urdu awaaz ke liye internet chahiye.")
            afterSpeech { dismiss() }
            return
        }
        if (!OfflineVoiceCheck.ready(ctx)) {
            listening = false
            reply("Boss, abhi internet nahi hai aur offline voice model bhi nahi hai.")
            afterSpeech { dismiss() }
            return
        }
        show("Sun raha hoon (English)...", true)
        Thread {
            val m = try {
                modelProvider()
            } catch (e: Exception) {
                null
            }
            handler.post {
                if (!active) return@post
                if (m == null) {
                    listening = false
                    noSpeechRound()
                    return@post
                }
                try {
                    val r = Recognizer(m, 16000.0f)
                    val s = SpeechService(r, 16000.0f)
                    voskRec = r
                    vosk = s
                    var delivered = false
                    s.startListening(object : org.vosk.android.RecognitionListener {
                        override fun onPartialResult(hypothesis: String?) {
                            val t = try {
                                JSONObject(hypothesis ?: "{}").optString("partial", "")
                            } catch (e: Exception) {
                                ""
                            }
                            if (t.isNotBlank()) handler.post { show(t) }
                        }

                        override fun onResult(hypothesis: String?) {
                            if (delivered) return
                            val t = try {
                                JSONObject(hypothesis ?: "{}").optString("text", "")
                            } catch (e: Exception) {
                                ""
                            }
                            if (t.isBlank()) return
                            delivered = true
                            handler.post {
                                stopVosk()
                                listening = false
                                handleSpoken(t)
                            }
                        }

                        override fun onFinalResult(hypothesis: String?) {}
                        override fun onError(exception: Exception?) {
                            if (delivered) return
                            delivered = true
                            handler.post {
                                stopVosk()
                                listening = false
                                noSpeechRound()
                            }
                        }

                        override fun onTimeout() {
                            if (delivered) return
                            delivered = true
                            handler.post {
                                stopVosk()
                                listening = false
                                noSpeechRound()
                            }
                        }
                    }, 9000)
                } catch (e: Exception) {
                    listening = false
                    noSpeechRound()
                }
            }
        }.start()
    }

    private fun stopVosk() {
        try {
            vosk?.stop()
        } catch (e: Exception) {
        }
        try {
            vosk?.shutdown()
        } catch (e: Exception) {
        }
        try {
            voskRec?.close()
        } catch (e: Exception) {
        }
        vosk = null
        voskRec = null
    }

    private fun stopRecognizers() {
        nmic?.stop()
        nmic = null
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
        stopVosk()
        listening = false
    }

    /** Kuch sunai nahi diya: ek do baar dobara, phir ijazat ke baghair chupke se band. */
    private fun noSpeechRound() {
        if (!active) return
        noSpeech++
        if (noSpeech < 3) {
            handler.postDelayed({ listen() }, 250)
        } else if (state == State.ASK_LEAVE) {
            bye()
        } else if (state == State.CONFIRM) {
            val cb = confirmCb
            confirmCb = null
            state = State.AGENT
            cb?.invoke(false)
        } else {
            dismiss()
        }
    }

    // ---------- Commands ----------
    private val yes = setOf(
        "haan", "han", "ha", "ji", "jao", "ja", "jaiye", "jaye", "chalo", "ok", "okay", "theek",
        "thik", "bilkul", "yes", "bas", "shukriya", "thanks", "thank"
    )
    private val no = setOf("nahi", "nahin", "no", "mat", "ruko", "ruk", "wait")

    private fun handleSpoken(raw: String) {
        if (!active) return
        val text = RomanUrdu.toRoman(raw).trim()
        if (text.isBlank()) {
            noSpeechRound()
            return
        }
        noSpeech = 0
        show("\u201C$text\u201D", false)
        val words = text.lowercase().split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }

        if (state == State.CONFIRM) {
            val shortAns = words.size <= 4
            when {
                shortAns && words.any { it in no } -> {
                    val cb = confirmCb
                    confirmCb = null
                    state = State.AGENT
                    show("Theek hai...", true)
                    cb?.invoke(false)
                }
                shortAns && words.any { it in yes } -> {
                    val cb = confirmCb
                    confirmCb = null
                    state = State.AGENT
                    show("Kaam jari...", true)
                    cb?.invoke(true)
                }
                else -> {
                    reply("Boss, sirf 'haan' ya 'nahi' bolein.")
                    afterSpeech { listen() }
                }
            }
            return
        }

        if (state == State.ASK_LEAVE) {
            val short = words.size <= 4
            when {
                short && (words.any { it in no } || "aur" in words || "abhi" in words) -> {
                    state = State.COMMAND
                    reply("Ji Boss, boliye.")
                    afterSpeech { listen() }
                }
                short && words.any { it in yes } -> bye()
                else -> runCommand(text, raw)
            }
            return
        }
        // Seedha "band karo / bas" bolne par bhi chala jaye.
        if (words.size <= 3 && (words.contains("bas") || words.contains("band"))) {
            bye()
            return
        }
        runCommand(text, raw)
    }

    private fun runCommand(text: String, raw: String) {
        callStarted = false
        state = State.COMMAND

        if (comm.handle(text, raw)) {
            finishTask()
            return
        }
        val action = PhoneActions.handle(ctx, text)
        if (action != null) {
            reply(action)
            finishTask()
            return
        }
        val local = LocalCommands.handle(ctx, text, online())
        if (local != null) {
            reply(local)
            finishTask()
            return
        }
        val agentWords = text.lowercase().split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }
        if (PhoneAgent.looksLikeTask(agentWords)) {
            startAgent(text)
            return
        }
        if (!online()) {
            reply("Boss, abhi internet nahi hai, is liye ye kaam cloud AI se nahi ho sakta.")
            finishTask()
            return
        }
        val secret = prefs.getString("secret", "") ?: ""
        if (secret.isBlank()) {
            reply("Boss, pehle NOVA app mein backend ka secret daalein.")
            finishTask()
            return
        }
        history.add(Msg(if (RomanUrdu.hasArabicScript(raw)) raw else text, true, true))
        show("NOVA soch raha hai...", false)
        cloudBusy++
        NovaApi.chat(history.takeLast(12).toList(), secret) { ok, answer ->
            handler.post {
                cloudBusy = maxOf(0, cloudBusy - 1)
                if (ok) history.add(Msg(answer, false, true))
                reply(answer)
                finishTask()
            }
        }
    }

    private fun startAgent(goal: String) {
        val secret = prefs.getString("secret", "") ?: ""
        when {
            !online() -> {
                reply("Boss, ye kaam ke liye internet chahiye.")
                finishTask()
            }
            secret.isBlank() -> {
                reply("Boss, pehle NOVA app mein backend ka secret daalein.")
                finishTask()
            }
            NovaAccessibilityService.instance == null -> {
                reply("Boss, ye kaam ke liye ⚙ se Accessibility (NOVA AI) on karein.")
                finishTask()
            }
            else -> {
                state = State.AGENT
                show("Kaam shuru kar raha hoon...", true)
                val a = PhoneAgent(
                    ctx, secret,
                    { s -> show(s, true) },
                    { q, cb -> askConfirm(q, cb) },
                    { _, msg ->
                        agent = null
                        state = State.COMMAND
                        reply(msg)
                        finishTask()
                    }
                )
                agent = a
                a.start(goal)
            }
        }
    }

    private fun askConfirm(q: String, cb: (Boolean) -> Unit) {
        if (!active) return
        confirmCb = cb
        state = State.CONFIRM
        noSpeech = 0
        reply(q)
        afterSpeech { listen() }
    }

    /** Kaam khatam: agar abhi koi jawab baaqi nahi to ijazat poochho. */
    private fun finishTask() {
        afterSpeech {
            if (!active) return@afterSpeech
            when {
                callStarted -> dismiss()
                comm.isPending() -> {
                    state = State.COMMAND
                    listen() // contact chunna / message ka text: dobara sunna
                }
                else -> {
                    state = State.ASK_LEAVE
                    reply("Kaam ho gaya Boss. Ab main jaoon?")
                    afterSpeech { listen() }
                }
            }
        }
    }

    private fun bye() {
        if (!active) return
        reply("Theek hai Boss. Allah hafiz!")
        afterSpeech { dismiss() }
    }

    // CommFlow ko permission chahiye: bubble se maangi nahi ja sakti, sirf check hoti hai.
    private fun ensure(perm: String, block: () -> Unit) {
        if (ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED) {
            block()
        } else {
            reply("Boss, '${perm.substringAfterLast('.')}' ki permission nahi hai. NOVA app khol kar allow karein.")
        }
    }
}

/** Offline model maujood hai ya nahi (service ke liye halka check). */
object OfflineVoiceCheck {
    fun ready(ctx: Context): Boolean {
        val dir = java.io.File(java.io.File(ctx.filesDir, "vosk"), OfflineVoice.MODEL_NAME)
        return java.io.File(dir, "am").isDirectory
    }
}
