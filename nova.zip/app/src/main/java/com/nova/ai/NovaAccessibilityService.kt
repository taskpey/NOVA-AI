package com.nova.ai

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 1) Screen lock aur power menu.
 * 2) WhatsApp mein sirf tab "Send" dabata hai jab NOVA ne khud message likh kar bheja ho.
 * Config mein sirf WhatsApp ke events aate hain; kisi aur app ka content nahi dekha jata.
 */
class NovaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NovaAccessibilityService? = null

        @Volatile
        private var sendUntil = 0L

        /** Agle 20 second mein WhatsApp ka Send button dabana hai. */
        fun armSend() {
            sendUntil = System.currentTimeMillis() + 20_000
        }

        private val WA = setOf("com.whatsapp", "com.whatsapp.w4b")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || System.currentTimeMillis() > sendUntil) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in WA) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() !in WA) return
        val btn = findSend(root, pkg) ?: return
        if (btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) sendUntil = 0L
    }

    private fun findSend(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        val byId = root.findAccessibilityNodeInfosByViewId("$pkg:id/send")
        if (!byId.isNullOrEmpty()) return byId[0]
        for (d in listOf("Send", "بھیجیں", "भेजें")) {
            val l = root.findAccessibilityNodeInfosByText(d) ?: continue
            val hit = l.firstOrNull {
                it.isClickable && it.contentDescription?.toString().equals(d, ignoreCase = true)
            }
            if (hit != null) return hit
        }
        return null
    }

    override fun onInterrupt() {}
}
