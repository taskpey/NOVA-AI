package com.nova.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 1) Screen lock aur power menu.
 * 2) WhatsApp mein sirf tab "Send" dabata hai jab NOVA ne khud message likh kar bheja ho.
 * 3) Phone Agent: aapke kehne par screen padh kar (password wale khane chhor kar) tap / type / scroll karta hai.
 */
class NovaAccessibilityService : AccessibilityService() {

    class Snap(val pkg: String, val text: String)

    companion object {
        @Volatile
        var instance: NovaAccessibilityService? = null

        @Volatile
        private var sendUntil = 0L

        @Volatile
        private var onSent: (() -> Unit)? = null

        /** Agle 20 second mein WhatsApp ka Send button dabana hai (dab jaye to callback). */
        fun armSend(callback: (() -> Unit)? = null) {
            onSent = callback
            sendUntil = System.currentTimeMillis() + 20_000
        }

        private val WA = setOf("com.whatsapp", "com.whatsapp.w4b")
    }

    private var lastNodes: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || System.currentTimeMillis() > sendUntil) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in WA) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() !in WA) return
        val btn = findSend(root, pkg) ?: return
        if (btn.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            sendUntil = 0L
            val cb = onSent
            onSent = null
            if (cb != null) android.os.Handler(android.os.Looper.getMainLooper()).post { cb() }
        }
    }

    private fun findSend(root: AccessibilityNodeInfo, pkg: String): AccessibilityNodeInfo? {
        val byId = root.findAccessibilityNodeInfosByViewId("$pkg:id/send")
        if (!byId.isNullOrEmpty()) return byId[0]
        for (d in listOf("Send", "بھیجیں", "भेजें")) {
            val l = root.findAccessibilityNodeInfosByText(d) ?: continue
            val hit = l.firstOrNull {
                it.isClickable && it.contentDescription?.toString().equals(d, ignoreCase = true)
            }
            if (hit != null) return hit
        }
        return null
    }

    // ---------- Phone Agent ----------
    /** Maujooda screen ki chhoti list: [index] flags "text" (desc). Password khane khali dikhte hain. */
    fun snapshot(): Snap? {
        val root = rootInActiveWindow ?: return null
        val pkg = root.packageName?.toString() ?: ""
        val nodes = ArrayList<AccessibilityNodeInfo>()
        val sb = StringBuilder()
        collect(root, nodes, sb)
        lastNodes = nodes
        return Snap(pkg, sb.toString())
    }

    private fun collect(n: AccessibilityNodeInfo, list: ArrayList<AccessibilityNodeInfo>, sb: StringBuilder) {
        if (list.size >= 80) return
        if (!n.isVisibleToUser) return
        val text = n.text?.toString()?.trim().orEmpty()
        val desc = n.contentDescription?.toString()?.trim().orEmpty()
        val interesting = n.isClickable || n.isScrollable || n.isEditable || n.isCheckable ||
            text.isNotEmpty() || desc.isNotEmpty()
        if (interesting) {
            val i = list.size
            list.add(n)
            val flags = buildString {
                if (n.isClickable) append('c')
                if (n.isScrollable) append('s')
                if (n.isEditable) append('e')
                if (n.isCheckable) append(if (n.isChecked) 'K' else 'k')
                if (n.isFocused) append('f')
            }
            sb.append('[').append(i).append("] ").append(flags.ifEmpty { "-" })
            if (n.isPassword) {
                sb.append(" (password khana)")
            } else {
                if (text.isNotEmpty()) sb.append(" \"").append(text.take(80).replace('\n', ' ')).append('"')
                if (desc.isNotEmpty() && desc != text) {
                    sb.append(" (").append(desc.take(60).replace('\n', ' ')).append(')')
                }
            }
            sb.append('\n')
        }
        for (c in 0 until n.childCount) {
            val ch = n.getChild(c) ?: continue
            collect(ch, list, sb)
        }
    }

    fun clickIndex(i: Int): Boolean {
        val node = lastNodes.getOrNull(i) ?: return false
        var cur: AccessibilityNodeInfo? = node
        while (cur != null && !cur.isClickable) cur = cur.parent
        if (cur != null && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        node.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    fun typeText(i: Int?, text: String): Boolean {
        var node: AccessibilityNodeInfo? = i?.let { lastNodes.getOrNull(it) }
        if (node == null || !node.isEditable) {
            node = findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: lastNodes.firstOrNull { it.isEditable && !it.isPassword }
        }
        if (node == null || node.isPassword) return false
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun imeEnter(): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        val node = findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    fun global(action: Int): Boolean = performGlobalAction(action)

    /** Abhi screen par kaunsi app hai. */
    fun foregroundPackage(): String? = rootInActiveWindow?.packageName?.toString()

    /** direction: up / down / left / right (ungli ki harkat ki simt). */
    fun swipe(direction: String): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val (x1, y1, x2, y2) = when (direction) {
            "up" -> listOf(w / 2, h * 0.72f, w / 2, h * 0.28f)
            "down" -> listOf(w / 2, h * 0.28f, w / 2, h * 0.72f)
            "left" -> listOf(w * 0.8f, h / 2, w * 0.2f, h / 2)
            "right" -> listOf(w * 0.2f, h / 2, w * 0.8f, h / 2)
            else -> return false
        }
        val p = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        return dispatch(p, 320)
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return dispatch(p, 60)
    }

    private fun dispatch(p: Path, ms: Long): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms))
            .build()
        return dispatchGesture(g, null, null)
    }

    override fun onInterrupt() {}
}
