package com.nova.ai

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * NOVA ka apna mic: Google ki voice service ke bina. Khud record karta hai, jab aap bolna band karte
 * hain to awaaz backend (AI) ko bhej kar likhwa leta hai. Beep nahi, "service disconnect" nahi,
 * aur jab tak aap na rokein mic chalta rehta hai (caller har baat ke baad dobara start karta hai).
 */
class NovaMic(
    private val secret: String,
    private val urdu: Boolean,
    private val listener: Listener
) {
    interface Listener {
        fun onLevel(level: Float)
        fun onStatus(text: String)

        /** text khali ho sakta hai (kuch sunai nahi diya). */
        fun onText(text: String)
        fun onFailed(fatal: Boolean, message: String)
    }

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var gen = 0

    @Volatile
    private var running = false

    fun isRunning() = running

    fun start() {
        if (running) return
        running = true
        val my = ++gen
        Thread { record(my) }.start()
    }

    fun stop() {
        gen++ // purane thread ke callbacks ignore honge
        running = false
    }

    private fun alive(my: Int) = my == gen

    private fun post(my: Int, block: () -> Unit) {
        main.post { if (alive(my)) block() }
    }

    private fun record(my: Int) {
        val rate = 16000
        val frame = 320 // 20 ms
        val minBuf = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        var rec: AudioRecord? = null
        try {
            for (src in intArrayOf(MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)) {
                val r = AudioRecord(
                    src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    max(minBuf, rate * 2)
                )
                if (r.state == AudioRecord.STATE_INITIALIZED) {
                    rec = r
                    break
                }
                r.release()
            }
        } catch (e: Exception) {
            rec = null
        }
        if (rec == null) {
            running = false
            post(my) { listener.onFailed(true, "mic shuru nahi hua") }
            return
        }

        val pcm = ByteArrayOutputStream()
        val pre = ArrayDeque<ShortArray>()
        val buf = ShortArray(frame)
        var noise = 0.0
        var calib = 0
        var threshold = 450.0
        var speaking = false
        var speechFrames = 0
        var silenceFrames = 0
        var idleFrames = 0
        var levelTick = 0
        var finished = false

        try {
            rec.startRecording()
            post(my) { listener.onStatus("Sun raha hoon...") }
            while (alive(my) && !finished) {
                val n = rec.read(buf, 0, frame)
                if (n <= 0) {
                    if (n < 0) break
                    continue
                }
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
                val rms = sqrt(sum / n)

                if (++levelTick % 3 == 0) {
                    val lv = min(1f, (rms / 3500.0).toFloat())
                    post(my) { listener.onLevel(lv) }
                }

                if (calib < 12) { // pehle 240 ms: aas-paas ka shor napo
                    noise += rms
                    calib++
                    if (calib == 12) threshold = max(noise / 12 * 3.0, 300.0)
                    continue
                }

                val frameCopy = buf.copyOf(n)
                if (!speaking) {
                    pre.addLast(frameCopy)
                    if (pre.size > 15) pre.removeFirst()
                    if (rms > threshold) {
                        speaking = true
                        speechFrames = 0
                        silenceFrames = 0
                        for (f in pre) writePcm(pcm, f)
                        pre.clear()
                        post(my) { listener.onStatus("Sun raha hoon...") }
                    } else if (++idleFrames > 450) { // 9 second kuch nahi bola
                        finished = true
                    }
                } else {
                    writePcm(pcm, frameCopy)
                    if (rms > threshold * 0.6) {
                        speechFrames++
                        silenceFrames = 0
                    } else {
                        silenceFrames++
                    }
                    val total = pcm.size() / 2
                    if ((silenceFrames >= 70 && speechFrames >= 12) || total > rate * 14) finished = true
                    else if (silenceFrames >= 70) { // sirf chhoti awaaz thi, dobara intezar
                        speaking = false
                        pcm.reset()
                        idleFrames = 0
                    }
                }
            }
        } catch (e: Exception) {
            running = false
            post(my) { listener.onFailed(true, "mic error") }
            return
        } finally {
            try {
                rec.stop()
            } catch (e: Exception) {
            }
            rec.release()
        }

        if (!alive(my)) {
            running = false
            return
        }
        if (pcm.size() < 2 * rate / 3) { // 0.3 second se kam: kuch nahi bola
            running = false
            post(my) { listener.onText("") }
            return
        }

        post(my) {
            listener.onLevel(0f)
            listener.onStatus("Samajh raha hoon...")
        }
        val wav = toWav(normalize(pcm.toByteArray()), rate)
        val r = NovaApi.transcribe(wav, urdu, secret)
        running = false
        when {
            r.ok -> post(my) { listener.onText(r.text) }
            r.fatal -> post(my) { listener.onFailed(true, r.text) }
            else -> post(my) { listener.onFailed(false, r.text) }
        }
    }

    /** Dheemi awaaz ko uthata hai taake AI behtar samjhe. */
    private fun normalize(pcm: ByteArray): ByteArray {
        var peak = 0
        var i = 0
        while (i + 1 < pcm.size) {
            val s = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort().toInt()
            peak = max(peak, abs(s))
            i += 2
        }
        if (peak < 200) return pcm
        val gain = min(8.0, 24000.0 / peak)
        if (gain < 1.15) return pcm
        val out = ByteArray(pcm.size)
        i = 0
        while (i + 1 < pcm.size) {
            val s = ((pcm[i + 1].toInt() shl 8) or (pcm[i].toInt() and 0xFF)).toShort().toInt()
            val v = (s * gain).toInt().coerceIn(-32768, 32767)
            out[i] = (v and 0xFF).toByte()
            out[i + 1] = ((v shr 8) and 0xFF).toByte()
            i += 2
        }
        return out
    }

    private fun writePcm(out: ByteArrayOutputStream, f: ShortArray) {
        for (s in f) {
            out.write(s.toInt() and 0xFF)
            out.write((s.toInt() shr 8) and 0xFF)
        }
    }

    private fun toWav(pcm: ByteArray, rate: Int): ByteArray {
        val out = ByteArrayOutputStream(pcm.size + 44)
        fun i32(v: Int) {
            out.write(v and 0xFF); out.write((v shr 8) and 0xFF)
            out.write((v shr 16) and 0xFF); out.write((v shr 24) and 0xFF)
        }

        fun i16(v: Int) {
            out.write(v and 0xFF); out.write((v shr 8) and 0xFF)
        }
        out.write("RIFF".toByteArray()); i32(36 + pcm.size)
        out.write("WAVE".toByteArray()); out.write("fmt ".toByteArray())
        i32(16); i16(1); i16(1); i32(rate); i32(rate * 2); i16(2); i16(16)
        out.write("data".toByteArray()); i32(pcm.size)
        out.write(pcm)
        return out.toByteArray()
    }
}
