package com.nova.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object NovaApi {
    private const val ENDPOINT = "https://nova-backend-steel.vercel.app/api/chat"

    fun chat(history: List<Msg>, secret: String, cb: (Boolean, String) -> Unit) {
        Thread {
            try {
                // Ek hi role ke lagataar messages ko jod do (Gemini alternate roles chahta hai).
                val merged = ArrayList<Pair<Boolean, String>>()
                for (m in history) {
                    val last = merged.lastOrNull()
                    if (last != null && last.first == m.fromUser) {
                        merged[merged.size - 1] = last.first to (last.second + "\n" + m.text)
                    } else {
                        merged.add(m.fromUser to m.text)
                    }
                }
                val arr = JSONArray()
                for ((fromUser, text) in merged) {
                    arr.put(
                        JSONObject()
                            .put("role", if (fromUser) "user" else "model")
                            .put("text", text)
                    )
                }
                val body = JSONObject().put("messages", arr).toString()

                val conn = URL(ENDPOINT).openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 40000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.setRequestProperty("x-nova-key", secret)
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                val json = try { JSONObject(text) } catch (e: Exception) { JSONObject() }
                conn.disconnect()

                when {
                    code in 200..299 -> {
                        val reply = json.optString("reply", "").trim()
                        cb(true, if (reply.isEmpty()) "Boss, jawab khali aaya." else reply)
                    }
                    code == 401 ->
                        cb(false, "Boss, secret galat hai. Upar ⚙ button se dobara daalein.")
                    else ->
                        cb(
                            false,
                            "Boss, AI se jawab nahi mila (code $code): " +
                                json.optString("error", "unknown").take(150)
                        )
                }
            } catch (e: Exception) {
                cb(false, "Boss, server tak pohanch nahi saka. Internet check karein.")
            }
        }.start()
    }
}
