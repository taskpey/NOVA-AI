package com.nova.ai

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Offline commands: kaam karte hain bina internet ke, aur online mein bhi foran jawab dete hain. */
object LocalCommands {

    private fun tokens(t: String): List<String> =
        t.lowercase(Locale.ROOT).split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }

    fun handle(ctx: Context, text: String, online: Boolean): String? {
        val tk = tokens(text)
        if (tk.isEmpty() || tk.size > 14) return null
        fun has(vararg w: String) = w.any { it in tk }

        // "Aapko kis ne banaya?" / "who made you" / "tumhara owner kaun hai"
        val askWho = has("kis", "kisne", "kisnay", "who", "kaun", "kon", "کس", "کون")
        val madeWord = has(
            "banaya", "banayi", "banai", "bnaya", "banaye", "banane", "create", "created", "made",
            "develop", "developed", "developer", "owner", "malik", "creator", "maker", "بنایا"
        )
        if (askWho && madeWord) {
            return "Mujhe Nova Studio ke Owner Umar Rajpoot ne banaya hai."
        }

        // Calculator: "5 plus 3", "20 percent of 500", "12 ko 4 se multiply karo"
        calc(text, tk)?.let { return it }

        if (tk.size > 8) return null

        return when {
            has("sikka", "coin", "toss") && has("uchalo", "uchal", "toss", "flip", "phenko", "karo", "kar") ->
                "Boss, sikka uchala: " + if (Math.random() < 0.5) "Heads (Sar)." else "Tails (Pat)."

            has("dice", "pasa", "ludo") && has("roll", "phenko", "uchalo", "karo", "kar", "do") ->
                "Boss, dice par " + (1 + (Math.random() * 6).toInt()) + " aaya."

            has("storage", "space", "memory", "jagah") && has("kitni", "kitna", "bachi", "bacha", "free", "available") ->
                storage()

            (has("phone", "mobile") && has("model", "naam", "name")) ||
                (has("android") && has("version", "konsa", "kaunsa", "which")) ->
                "Boss, ye ${Build.MANUFACTURER} ${Build.MODEL} hai, Android ${Build.VERSION.RELEASE}."

            tk.size <= 3 && has("help", "madad", "commands", "مدد") ->
                "Boss, bina internet ke main ye kar sakta hoon: koi bhi app kholna, torch, alarm, timer, " +
                    "reminder, volume, brightness, screenshot lena, home/back/recent apps, notification panel, " +
                    "call/SMS (contacts se), call log, calculator (5 plus 3), time, date, battery, storage, " +
                    "sikka/dice, silent/vibrate mode, rasta (maps). Baqi sawalon ke liye internet chahiye."

            has("battery", "bettery", "batry", "بیٹری") -> battery(ctx)

            has("time", "waqt", "baje", "وقت") ->
                "Boss, abhi " + SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date()) + " hue hain."

            has("date", "tarikh", "tareekh", "تاریخ") ||
                (has("din", "دن", "day") && has("aaj", "آج", "kya", "کیا", "today", "what")) ->
                "Boss, aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date()) + " hai."

            has("mode", "status") ->
                if (online) "Boss, main ONLINE mode mein hoon. Cloud AI chal raha hai."
                else "Boss, main OFFLINE mode mein hoon. Sirf local commands chalenge."

            has("kon", "kaun", "who", "کون") && has("ap", "aap", "tum", "you", "ho", "آپ", "تم") ->
                "Main NOVA hoon, aapka personal voice assistant. Bataiye, kya help kar sakta hoon?"

            tk.size <= 3 && has("assalam", "salam", "salaam", "hello", "سلام") ->
                "Walaikum Assalam Boss! Bataiye, kya help kar sakta hoon?"

            tk.size <= 3 && has("shukriya", "thanks", "thank", "شکریہ") ->
                "Koi baat nahi Boss!"

            else -> null
        }
    }

    private fun storage(): String {
        return try {
            val st = StatFs(Environment.getDataDirectory().path)
            val gb = 1024.0 * 1024 * 1024
            val free = st.availableBytes / gb
            val total = st.totalBytes / gb
            "Boss, phone mein %.1f GB jagah khali hai (kul %.0f GB).".format(Locale.ENGLISH, free, total)
        } catch (e: Exception) {
            "Boss, storage ki maloomat nahi mil rahi."
        }
    }

    // ---------- Calculator ----------
    private val opWords = mapOf(
        "plus" to "+", "jama" to "+", "add" to "+", "aur" to "+",
        "minus" to "-", "ghata" to "-", "ghatao" to "-", "tafreeq" to "-", "less" to "-",
        "into" to "*", "times" to "*", "multiply" to "*", "zarb" to "*", "guna" to "*", "x" to "*",
        "divide" to "/", "by" to "/", "taqseem" to "/", "bhag" to "/", "divided" to "/"
    )

    private fun fmt(v: Double): String =
        if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else "%.4f".format(Locale.ENGLISH, v).trimEnd('0').trimEnd('.')

    private fun calc(text: String, tk: List<String>): String? {
        val norm = buildString {
            for (c in text.lowercase(Locale.ROOT)) append(if (c.isDigit()) ('0' + Character.digit(c, 10)) else c)
        }
        val nums = Regex("\\d+(?:\\.\\d+)?").findAll(norm).map { it.value.toDouble() }.toList()
        if (nums.size < 2) return null
        // Waqt / alarm wale jumle calculator nahi hain.
        val skip = setOf(
            "alarm", "timer", "minute", "minutes", "baje", "hour", "ghanta", "ghante", "remind", "reminder",
            "call", "message", "brightness", "volume", "percent", "fisad"
        )
        if (tk.any { it in setOf("percent", "fisad") } || norm.contains('%')) {
            if (tk.any { it in setOf("alarm", "timer", "remind", "reminder", "brightness", "volume") }) return null
            val v = nums[0] * nums[1] / 100.0
            return "Boss, jawab hai ${fmt(v)}."
        }
        if (tk.any { it in skip }) return null

        val vals = ArrayList<Double>()
        val ops = ArrayList<Char>()
        val needAur = tk.any { it in setOf("kitne", "kitna", "hue", "hota", "total", "equals", "barabar") }
        var expectNum = true
        for (m in Regex("\\d+(?:\\.\\d+)?|[+\\-*/×÷]|[a-z]+").findAll(norm)) {
            val t = m.value
            if (t[0].isDigit()) {
                if (!expectNum) return null
                vals.add(t.toDouble())
                expectNum = false
            } else {
                val op = when (t) {
                    "+", "-", "*", "/" -> t
                    "×" -> "*"
                    "÷" -> "/"
                    "aur" -> if (needAur) "+" else null
                    else -> opWords[t]
                } ?: continue
                if (expectNum) return null
                ops.add(op[0])
                expectNum = true
            }
        }
        if (expectNum || vals.size < 2 || ops.size != vals.size - 1) return null
        // pehle * aur /, phir + aur -
        var i = 0
        while (i < ops.size) {
            if (ops[i] == '*' || ops[i] == '/') {
                if (ops[i] == '/' && vals[i + 1] == 0.0) return "Boss, zero se taqseem nahi ho sakti."
                val r = if (ops[i] == '*') vals[i] * vals[i + 1] else vals[i] / vals[i + 1]
                vals[i] = r
                vals.removeAt(i + 1)
                ops.removeAt(i)
            } else {
                i++
            }
        }
        var res = vals[0]
        for (k in ops.indices) res = if (ops[k] == '+') res + vals[k + 1] else res - vals[k + 1]
        return "Boss, jawab hai ${fmt(res)}."
    }

    private fun battery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return "Boss, battery ki maloomat nahi mil rahi."
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return "Boss, battery ki maloomat nahi mil rahi."
        val pct = level * 100 / scale
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        var msg = "Boss, battery $pct% hai"
        msg += if (charging) " aur charging ho rahi hai." else "."
        if (!charging && pct <= 20) msg += " Charger laga lein."
        return msg
    }
}
