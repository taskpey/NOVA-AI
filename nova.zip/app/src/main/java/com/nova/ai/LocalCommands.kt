package com.nova.ai

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Offline commands: kaam karte hain bina internet ke, aur online mein bhi foran jawab dete hain. */
object LocalCommands {

    private fun tokens(t: String): List<String> =
        t.lowercase(Locale.ROOT).split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }

    fun handle(ctx: Context, text: String, online: Boolean): String? {
        val tk = tokens(text)
        if (tk.isEmpty() || tk.size > 8) return null
        fun has(vararg w: String) = w.any { it in tk }

        return when {
            has("help", "madad", "commands", "مدد") ->
                "Boss, offline mein main ye kar sakta hoon: time, date, battery, mode ka status. " +
                    "Baqi sawalon ke liye internet chahiye."

            has("battery", "bettery", "batry", "بیٹری") -> battery(ctx)

            has("time", "waqt", "baje", "وقت") ->
                "Boss, abhi " + SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date()) + " hue hain."

            has("date", "tarikh", "tareekh", "تاریخ") ||
                (has("din", "دن") && has("aaj", "آج", "kya", "کیا")) ->
                "Boss, aaj " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date()) + " hai."

            has("mode", "status") ->
                if (online) "Boss, main ONLINE mode mein hoon. Cloud AI chal raha hai."
                else "Boss, main OFFLINE mode mein hoon. Sirf local commands chalenge."

            has("kon", "kaun", "who", "کون") && has("ap", "aap", "tum", "you", "ho", "آپ", "تم") ->
                "Main NOVA hoon, aapka personal voice assistant. Bataiye, kya help kar sakta hoon?"

            has("assalam", "salam", "salaam", "hello", "سلام") ->
                "Walaikum Assalam Boss! Bataiye, kya help kar sakta hoon?"

            has("shukriya", "thanks", "thank", "شکریہ") ->
                "Koi baat nahi Boss!"

            else -> null
        }
    }

    private fun battery(ctx: Context): String {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return "Boss, battery ki maloomat nahi mil rahi."
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (level < 0 || scale <= 0) return "Boss, battery ki maloomat nahi mil rahi."
        val pct = level * 100 / scale
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        var msg = "Boss, battery $pct% hai"
        msg += if (charging) " aur charging ho rahi hai." else "."
        if (!charging && pct <= 20) msg += " Charger laga lein."
        return msg
    }
}
