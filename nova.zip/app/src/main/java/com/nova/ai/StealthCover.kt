package com.nova.ai

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * WhatsApp ko chupke se chalate waqt poori screen par NOVA ka parda (taake WhatsApp ki screen nazar na aaye).
 * Kaam khatam hote hi hat jata hai; parde par tap karne se bhi foran hat jata hai.
 */
class StealthCover(ctx: Context) {
    private val app = ctx.applicationContext
    private val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: View? = null

    private fun dp(v: Int) = (v * app.resources.displayMetrics.density).toInt()

    fun show(message: String): Boolean {
        if (!Settings.canDrawOverlays(app)) return false
        return try {
            val root = FrameLayout(app).apply {
                setBackgroundColor(0xFF05070F.toInt())
                setOnClickListener { hide() }
            }
            val orb = NovaCoreView(app).apply { listening = true }
            root.addView(orb, FrameLayout.LayoutParams(dp(170), dp(170), Gravity.CENTER))
            val tv = TextView(app).apply {
                text = message
                setTextColor(0xFFE6F6FF.toInt())
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(dp(24), 0, dp(24), 0)
            }
            root.addView(
                tv,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM
                ).apply { bottomMargin = dp(150) }
            )
            val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else WindowManager.LayoutParams.TYPE_PHONE
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.OPAQUE
            )
            wm.addView(root, lp)
            view = root
            true
        } catch (e: Exception) {
            false
        }
    }

    fun hide() {
        val v = view ?: return
        view = null
        try {
            wm.removeView(v)
        } catch (e: Exception) {
        }
    }
}
