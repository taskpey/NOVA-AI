package com.nova.ai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Wake word: "Hi Nova" / "Hello Nova" / "Nova bat suno". App band ho tab bhi chalta hai.
 * Offline Vosk model use karta hai (internet nahi chahiye). Awaaz phone se bahar nahi jati;
 * wake word milte hi NOVA screen par khulta hai aur command sunta hai.
 */
class WakeService : Service() {

    companion object {
        private const val CH = "nova_wake"
        private const val CH_ALERT = "nova_wake_alert"
        private const val NID = 7
        const val ALERT_ID = 8

        @Volatile
        var instance: WakeService? = null

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }

        /** Bubble se seedha kaam karwana (app se). */
        fun runTask(ctx: Context, goal: String) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, WakeService::class.java).putExtra("goal", goal)
            )
        }

        fun pause() {
            instance?.pauseListening()
        }

        fun resume() {
            instance?.resumeListening()
        }

        // Vosk sirf in alfaaz ko dhoondta hai (baqi sab [unk]): "Hi Nova" bar bar bolne ki zaroorat nahi.
        private val GRAMMAR = JSONArray(
            listOf(
                "hi nova", "hello nova", "hey nova", "nova", "hi noah", "hello noah", "hey noah", "noah",
                "hello novo", "novo", "[unk]"
            )
        ).toString()

        private val WAKE = setOf("nova", "novo", "noah", "novah", "novar", "nover", "noba")
    }

    private val handler = Handler(Looper.getMainLooper())
    private var model: Model? = null

    private var callAssistant: CallAssistant? = null

    @Volatile
    private var wakeGen = 0
    private var wakeThread: Thread? = null

    @Volatile
    private var paused = false

    @Volatile
    private var triggered = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        paused = MainActivity.visible // app khuli ho to mic app ke paas rehne do
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "NOVA wake word", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_ALERT, "NOVA jagao", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    private fun sp() = getSharedPreferences("nova", Context.MODE_PRIVATE)

    private fun onCallStarted() {
        pauseListening()
        bubble?.dismiss()
    }

    private fun onCallEnded() {
        val wakeOn = sp().getBoolean("wake", false)
        val callOn = sp().getBoolean("callAssist", false)
        when {
            wakeOn && !MainActivity.visible -> handler.postDelayed({ resumeListening() }, 800)
            !wakeOn && !callOn && bubble == null -> stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val wakeOn = sp().getBoolean("wake", false)
        val callOn = sp().getBoolean("callAssist", false)
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle(if (wakeOn) "NOVA sun raha hai" else "NOVA call assistant chalu hai")
            .setContentText(
                if (wakeOn) "\"Hi Nova\" ya \"Hello Nova\" bolein" else "Aane wali calls sambhalne ke liye tayyar"
            )
            .setOngoing(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NID, n)
        }
        val outName = intent?.getStringExtra("out_name")
        if (callOn || outName != null) {
            val ca = callAssistant
                ?: CallAssistant(this, { onCallStarted() }, { onCallEnded() }).also { callAssistant = it }
            ca.register()
            if (outName != null) {
                ca.prepareOutgoing(
                    outName,
                    intent?.getStringExtra("out_number") ?: "",
                    intent?.getStringExtra("out_instr") ?: ""
                )
            }
        } else {
            callAssistant?.unregister()
        }

        val goal = intent?.getStringExtra("goal")
        when {
            goal != null -> {
                pauseListening()
                handler.post { startBubble(goal) }
            }
            outName != null -> {}
            wakeOn && !MainActivity.visible -> resumeListening()
            !wakeOn && !callOn -> stopSelf()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        paused = true
        bubble?.dismiss()
        bubble = null
        callAssistant?.shutdown()
        callAssistant = null
        handler.removeCallbacksAndMessages(null)
        pauseListening()
        synchronized(modelLock) {
            try {
                model?.close()
            } catch (e: Exception) {
            }
            model = null
        }
        super.onDestroy()
    }

    // ---------- Listening ----------
    fun resumeListening() {
        if (bubble != null) return // bubble mic istemal kar raha hai
        if (callAssistant?.isBusy() == true) return // call chal rahi hai
        paused = false
        triggered = false
        synchronized(this) {
            val t = wakeThread
            if (t != null && t.isAlive) return
            wakeThread = null
        }
        Thread { startRecognition() }.start()
    }

    /** Mic chhor do (app / bubble ko chahiye). Wake thread ke band hone tak thora intezar. */
    fun pauseListening() {
        paused = true
        wakeGen++
        val t = synchronized(this) { wakeThread }
        try {
            if (t != null && t !== Thread.currentThread()) t.join(800)
        } catch (e: InterruptedException) {
        }
    }

    private val modelLock = Any()

    private fun loadModel(): Model? = synchronized(modelLock) {
        if (model == null) {
            val dir = File(File(filesDir, "vosk"), OfflineVoice.MODEL_NAME)
            if (!File(dir, "am").isDirectory) return null
            model = Model(dir.absolutePath)
        }
        model
    }

    private fun startRecognition() {
        if (paused) return
        try {
            val m = loadModel()
            if (m == null) {
                stopSelf()
                return
            }
            synchronized(this) {
                val old = wakeThread
                if (paused || (old != null && old.isAlive)) return
                val my = ++wakeGen
                val t = Thread { wakeLoop(m, my) }
                wakeThread = t
                t.start()
            }
        } catch (e: Exception) {
            synchronized(this) { wakeThread = null }
        }
    }

    /** Apna mic loop: dheemi awaaz par khud gain barhata hai, phir Vosk ko deta hai. */
    private fun wakeLoop(m: Model, my: Int) {
        var recognizer: Recognizer? = null
        var ar: AudioRecord? = null
        try {
            recognizer = Recognizer(m, 16000.0f, GRAMMAR)
            val rate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            for (src in intArrayOf(MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC)) {
                val r = AudioRecord(
                    src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    max(minBuf, rate * 2)
                )
                if (r.state == AudioRecord.STATE_INITIALIZED) {
                    ar = r
                    break
                }
                r.release()
            }
            val rec = ar ?: return
            rec.startRecording()
            val buf = ShortArray(1600) // 100 ms
            var level = 1500.0
            while (my == wakeGen && !paused) {
                val n = rec.read(buf, 0, buf.size)
                if (n < 0) break
                if (n == 0) continue
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
                level = level * 0.92 + sqrt(sum / n) * 0.08
                val gain = (3500.0 / max(level, 150.0)).coerceIn(1.0, 5.0)
                if (gain > 1.05) {
                    for (i in 0 until n) {
                        buf[i] = (buf[i] * gain).toInt().coerceIn(-32768, 32767).toShort()
                    }
                }
                if (recognizer.acceptWaveForm(buf, n)) checkWake(recognizer.result, "text")
                else checkWake(recognizer.partialResult, "partial")
            }
        } catch (e: Exception) {
        } finally {
            try {
                ar?.stop()
            } catch (e: Exception) {
            }
            ar?.release()
            try {
                recognizer?.close()
            } catch (e: Exception) {
            }
            synchronized(this) {
                if (wakeThread === Thread.currentThread()) wakeThread = null
            }
        }
    }

    private fun checkWake(json: String?, key: String) {
        if (paused || triggered) return
        val t = try {
            JSONObject(json ?: "{}").optString(key, "")
        } catch (e: Exception) {
            ""
        }
        if (t.isBlank()) return
        val w = t.lowercase().split(Regex("\\s+"))
        val hit = w.any { it in WAKE } || w.zipWithNext().any { it.first == "no" && it.second == "va" }
        if (hit) {
            triggered = true
            handler.post { onWake() }
        }
    }

    private var bubble: VoiceBubble? = null

    private fun onWake() {
        pauseListening()
        if (!startBubble(null)) {
            // Overlay permission nahi mili: purana tareeqa (app kholna).
            launchNova()
            handler.postDelayed({ if (!MainActivity.visible) resumeListening() }, 20_000)
        }
    }

    /** App khole baghair neeche gol bubble: kaam karo, ijazat lo, chale jao. */
    private fun startBubble(goal: String?): Boolean {
        if (bubble != null) return true
        val b = VoiceBubble(this, { loadModel() }, goal) {
            bubble = null
            if (instance != null) {
                val wakeOn = sp().getBoolean("wake", false)
                val callOn = sp().getBoolean("callAssist", false)
                if (wakeOn) {
                    handler.postDelayed({ if (!MainActivity.visible) resumeListening() }, 800)
                } else if (!callOn) {
                    stopSelf() // wake word band tha, sirf kaam ke liye chala tha
                }
            }
        }
        if (!b.start()) return false
        bubble = b
        return true
    }

    private fun launchNova() {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("wake", true)
        val pi = PendingIntent.getActivity(
            this, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        // Fallback: agar phone seedha app kholne na de to ye notification kholega.
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("NOVA")
            .setContentText("Ji Boss, boliye...")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        getSystemService(NotificationManager::class.java).notify(ALERT_ID, n)
        try {
            startActivity(i)
        } catch (e: Exception) {
        }
    }
}
