package com.nova.ai

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File

/**
 * Wake word: "Hi Nova" / "Hello Nova" / "Nova bat suno". App band ho tab bhi chalta hai.
 * Offline Vosk model use karta hai (internet nahi chahiye). Awaaz phone se bahar nahi jati;
 * wake word milte hi NOVA screen par khulta hai aur command sunta hai.
 */
class WakeService : Service() {

    companion object {
        private const val CH = "nova_wake"
        private const val CH_ALERT = "nova_wake_alert"
        private const val NID = 7
        const val ALERT_ID = 8

        @Volatile
        var instance: WakeService? = null

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, WakeService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, WakeService::class.java))
        }

        fun pause() {
            instance?.pauseListening()
        }

        fun resume() {
            instance?.resumeListening()
        }

        private val WAKE = setOf("nova", "novo", "noah", "nover", "novar", "novah", "noba")
    }

    private val handler = Handler(Looper.getMainLooper())
    private var model: Model? = null
    private var rec: Recognizer? = null
    private var speech: SpeechService? = null

    @Volatile
    private var paused = false

    @Volatile
    private var triggered = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        paused = MainActivity.visible // app khuli ho to mic app ke paas rehne do
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "NOVA wake word", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_ALERT, "NOVA jagao", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("NOVA sun raha hai")
            .setContentText("\"Hi Nova\" ya \"Hello Nova\" bolein")
            .setOngoing(true)
            .setContentIntent(open)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NID, n)
        }
        if (!MainActivity.visible) resumeListening()
        return START_STICKY
    }

    override fun onDestroy() {
        instance = null
        paused = true
        handler.removeCallbacksAndMessages(null)
        releaseRecognizer()
        synchronized(modelLock) {
            try {
                model?.close()
            } catch (e: Exception) {
            }
            model = null
        }
        super.onDestroy()
    }

    // ---------- Listening ----------
    @Synchronized
    fun resumeListening() {
        paused = false
        triggered = false
        if (speech != null) return
        Thread { startRecognition() }.start()
    }

    @Synchronized
    fun pauseListening() {
        paused = true
        releaseRecognizer()
    }

    @Synchronized
    private fun releaseRecognizer() {
        try {
            speech?.stop()
        } catch (e: Exception) {
        }
        try {
            speech?.shutdown()
        } catch (e: Exception) {
        }
        try {
            rec?.close()
        } catch (e: Exception) {
        }
        speech = null
        rec = null
    }

    private val modelLock = Any()

    private fun loadModel(): Model? = synchronized(modelLock) {
        if (model == null) {
            val dir = File(File(filesDir, "vosk"), OfflineVoice.MODEL_NAME)
            if (!File(dir, "am").isDirectory) return null
            model = Model(dir.absolutePath)
        }
        model
    }

    private fun startRecognition() {
        if (paused) return
        try {
            val m = loadModel()
            if (m == null) {
                stopSelf()
                return
            }
            synchronized(this) {
                if (paused || speech != null) return
                val r = Recognizer(m, 16000.0f)
                val s = SpeechService(r, 16000.0f)
                rec = r
                speech = s
                s.startListening(object : RecognitionListener {
                    override fun onPartialResult(hypothesis: String?) = checkWake(hypothesis, "partial")
                    override fun onResult(hypothesis: String?) = checkWake(hypothesis, "text")
                    override fun onFinalResult(hypothesis: String?) {}
                    override fun onError(exception: Exception?) {}
                    override fun onTimeout() {}
                })
            }
        } catch (e: Exception) {
            synchronized(this) {
                speech = null
                rec = null
            }
        }
    }

    private fun checkWake(json: String?, key: String) {
        if (paused || triggered) return
        val t = try {
            JSONObject(json ?: "{}").optString(key, "")
        } catch (e: Exception) {
            ""
        }
        if (t.isBlank()) return
        val w = t.lowercase().split(Regex("\\s+"))
        val hit = w.any { it in WAKE } || w.zipWithNext().any { it.first == "no" && it.second == "va" }
        if (hit) {
            triggered = true
            handler.post { onWake() }
        }
    }

    private fun onWake() {
        pauseListening()
        launchNova()
        // Agar app khuli hi nahi (phone ne roka), to 20 second baad dobara sunna shuru.
        handler.postDelayed({ if (!MainActivity.visible) resumeListening() }, 20_000)
    }

    private fun launchNova() {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("wake", true)
        val pi = PendingIntent.getActivity(
            this, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        // Fallback: agar phone seedha app kholne na de to ye notification kholega.
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_notify)
            .setContentTitle("NOVA")
            .setContentText("Ji Boss, boliye...")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        getSystemService(NotificationManager::class.java).notify(ALERT_ID, n)
        try {
            startActivity(i)
        } catch (e: Exception) {
        }
    }
}
