package com.nova.ai

import android.app.Activity
import android.content.Context
import android.content.Intent

/** Activity ho ya Service (floating bubble), dono se screen kholne ke liye. */
fun Context.launch(i: Intent) {
    if (this !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    startActivity(i)
}
