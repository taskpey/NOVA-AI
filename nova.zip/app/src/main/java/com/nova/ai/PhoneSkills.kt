package com.nova.ai

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Seedhe Android ke tareeqe: gallery, screenshots, Downloads. (Bina AI ke, bharosemand.) */
object PhoneSkills {

    fun imagesPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
        else Manifest.permission.READ_EXTERNAL_STORAGE

    private val IMAGES: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    /** Sabse nayi photo (screenshot chhor kar; na mile to koi bhi nayi image). */
    @Suppress("DEPRECATION")
    fun latestPhoto(ctx: Context): Uri? {
        val proj = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DATA)
        ctx.contentResolver.query(
            IMAGES, proj, null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { c ->
            var n = 0
            var first: Uri? = null
            while (c.moveToNext() && n < 40) {
                val uri = ContentUris.withAppendedId(IMAGES, c.getLong(0))
                val path = (c.getString(1) ?: "").lowercase()
                if (first == null) first = uri
                if (!path.contains("screenshot")) return uri
                n++
            }
            return first
        }
        return null
    }

    /** Screenshots, nayi pehle. all=false ho to sirf sabse nayi. */
    @Suppress("DEPRECATION")
    fun screenshots(ctx: Context, all: Boolean): List<Uri> {
        val out = ArrayList<Uri>()
        val sel = "${MediaStore.Images.Media.DISPLAY_NAME} LIKE ? OR ${MediaStore.Images.Media.DATA} LIKE ?"
        ctx.contentResolver.query(
            IMAGES, arrayOf(MediaStore.Images.Media._ID), sel,
            arrayOf("Screenshot%", "%/Screenshots/%"),
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )?.use { c ->
            val limit = if (all) 60 else 1
            while (c.moveToNext() && out.size < limit) {
                out.add(ContentUris.withAppendedId(IMAGES, c.getLong(0)))
            }
        }
        return out
    }

    // ---------- Downloads ki safai ----------
    class MovePlan(val moves: List<Pair<File, File>>, val counts: Map<String, Int>)

    fun hasAllFilesAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true

    private fun category(ext: String): String = when (ext) {
        "jpg", "jpeg", "png", "gif", "webp", "heic", "bmp" -> "Images"
        "mp4", "mkv", "mov", "avi", "3gp", "webm" -> "Videos"
        "mp3", "m4a", "wav", "aac", "ogg", "opus", "flac" -> "Audio"
        "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "rtf", "odt" -> "Documents"
        "zip", "rar", "7z", "tar", "gz" -> "Archives"
        "apk", "xapk" -> "APKs"
        else -> "Other"
    }

    @Suppress("DEPRECATION")
    fun planDownloads(): MovePlan? {
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val files = dir.listFiles()?.filter {
            it.isFile && !it.name.startsWith(".") &&
                it.extension.lowercase() !in setOf("crdownload", "tmp", "part", "download")
        } ?: return null
        val moves = files.map { f -> f to File(File(dir, category(f.extension.lowercase())), f.name) }
        val counts = moves.groupingBy { it.second.parentFile?.name ?: "Other" }.eachCount()
        return MovePlan(moves, counts)
    }

    fun executeMoves(ctx: Context, plan: MovePlan): Int {
        var ok = 0
        val moved = ArrayList<String>()
        for ((src, dst) in plan.moves) {
            dst.parentFile?.mkdirs()
            var target = dst
            var n = 1
            while (target.exists()) {
                val ext = if (dst.extension.isEmpty()) "" else "." + dst.extension
                target = File(dst.parentFile, "${dst.nameWithoutExtension} ($n)$ext")
                n++
            }
            if (src.renameTo(target)) {
                ok++
                moved.add(target.absolutePath)
            }
        }
        if (moved.isNotEmpty()) MediaScannerConnection.scanFile(ctx, moved.toTypedArray(), null, null)
        return ok
    }
}
