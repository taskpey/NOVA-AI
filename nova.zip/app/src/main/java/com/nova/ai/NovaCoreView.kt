package com.nova.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

class NovaCoreView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private val blue = 0xFF00B4FF.toInt()
    private val purple = 0xFF8A2BE2.toInt()
    private var t = 0f
    var listening = false
        set(v) { field = v; invalidate() }
    private val rect = RectF()

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 6000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) {
            if (!anim.isStarted) anim.start()
        } else {
            anim.cancel()
        }
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val base = min(w, h) / 2f
        if (base <= 0f) return
        glowPaint.shader = RadialGradient(
            cx, cy, base,
            intArrayOf(0x6600B4FF, 0x228A2BE2, 0x00000000),
            floatArrayOf(0.3f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
        corePaint.shader = RadialGradient(
            cx, cy, base * 0.35f,
            intArrayOf(0xFFFFFFFF.toInt(), blue, purple),
            floatArrayOf(0f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(c: Canvas) {
        if (glowPaint.shader == null || corePaint.shader == null) return
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) / 2f

        c.drawCircle(cx, cy, base, glowPaint)

        val pulse = 1f + (if (listening) 0.12f else 0.05f) *
            sin(t * 2.0 * PI * (if (listening) 6.0 else 3.0)).toFloat()
        c.save()
        c.scale(pulse, pulse, cx, cy)
        c.drawCircle(cx, cy, base * 0.35f, corePaint)

        for (i in 0..2) {
            val r = base * (0.5f + 0.15f * i)
            ringPaint.strokeWidth = 4f + i
            ringPaint.color = if (i % 2 == 0) blue else purple
            val dir = if (i % 2 == 0) 1f else -1f
            c.save()
            c.rotate(dir * t * 360f * (i + 1), cx, cy)
            rect.set(cx - r, cy - r, cx + r, cy + r)
            c.drawArc(rect, 0f, 100f + 40f * i, false, ringPaint)
            c.drawArc(rect, 180f, 70f, false, ringPaint)
            c.restore()
        }
        c.restore()
    }
}
