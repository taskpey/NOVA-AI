package com.nova.ai

import android.Manifest
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.WindowManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity() {

    companion object {
        /** WakeService isse jaanta hai ke app screen par hai (tab mic app ke paas rehta hai). */
        @Volatile
        var visible = false
    }

    private var retries = 0

    // NOVA ka apna mic (AI se likhwata hai): Google mic se zyada bharosemand.
    private var nmic: NovaMic? = null
    private var usingNova = false
    private var novaFails = 0

    private fun canUseNovaMic(): Boolean =
        online && novaFails < 2 && prefs().getBoolean("novamic", false) &&
            !(prefs().getString("secret", "") ?: "").isBlank()

    private fun startNovaMic() {
        usingOffline = false
        usingNova = true
        tts?.stop()
        setListeningUi(true)
        nmic?.stop()
        val secret = prefs().getString("secret", "") ?: ""
        nmic = NovaMic(secret, urdu, object : NovaMic.Listener {
            override fun onLevel(level: Float) {
                if (listening) wave.push(level)
            }

            override fun onStatus(text: String) {
                if (listening) input.hint = "NOVA mic: $text"
            }

            override fun onText(text: String) {
                if (!usingNova) return
                setListeningUi(false)
                val t = RomanUrdu.toRoman(text.trim())
                input.setText("")
                if (t.isBlank()) {
                    if (continuous) scheduleResume()
                    else addMessage("Boss, awaaz samajh nahi aayi. Dobara bolein.", false)
                } else {
                    novaFails = 0
                    handleUserText(t)
                    if (continuous) scheduleResume()
                }
            }

            override fun onFailed(fatal: Boolean, message: String) {
                if (!usingNova) return
                novaFails += if (fatal) 2 else 1
                setListeningUi(false)
                if (fatal) {
                    addMessage("Boss, NOVA mic mein masla ($message). Google mic par ja raha hoon.", false, false)
                }
                if (continuous) {
                    handler.postDelayed({ if (continuous) startListening(false) }, 300)
                }
            }
        }).also { it.start() }
    }

    /** Mic par tap ke baad jab tak aap dobara tap na karein, NOVA sunta rehta hai. */
    private var continuous = false
    private var ttsBusy = false
    private var cloudBusy = 0

    private val resumeCheck = object : Runnable {
        override fun run() {
            if (!continuous || listening) return
            if (ttsBusy || cloudBusy > 0) {
                handler.postDelayed(this, 400)
                return
            }
            startListening(false)
        }
    }

    /** NOVA ka jawab (bolna / cloud reply) khatam hote hi dobara sunna shuru. */
    private fun scheduleResume() {
        handler.removeCallbacks(resumeCheck)
        handler.postDelayed(resumeCheck, 700)
    }

    private val messages = mutableListOf<Msg>()
    private lateinit var adapter: ChatAdapter
    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var statusText: TextView
    private lateinit var batteryText: TextView
    private lateinit var micBtn: TextView
    private lateinit var langBtn: TextView
    private lateinit var muteBtn: TextView
    private lateinit var core: NovaCoreView
    private lateinit var wave: WaveformView
    private lateinit var cm: ConnectivityManager
    private val handler = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var urdu = true
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var muted = false
    private var online = false
    private val offlineVoice by lazy { OfflineVoice(this) }
    private var usingOffline = false
    private var permAction: (() -> Unit)? = null

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val cb = permAction
            permAction = null
            if (granted) cb?.invoke()
            else addMessage(
                "Boss, permission nahi mili, is liye ye kaam nahi ho sakta. " +
                    "Phone Settings → Apps → NOVA AI → Permissions se allow kar sakte hain.",
                false
            )
        }

    private val comm by lazy {
        CommFlow(this, { t -> addMessage(t, false, false); speak(t) }, { p, a -> ensurePerm(p, a) })
    }

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                continuous = true
                startListening()
            } else Toast.makeText(this, "Boss, mic ki permission zaroori hai", Toast.LENGTH_LONG).show()
        }

    private fun hasInternet(caps: NetworkCapabilities?) =
        caps != null &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
            runOnUiThread { setOnline(hasInternet(caps)) }
        }

        override fun onLost(network: Network) {
            runOnUiThread { setOnline(false) }
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateBattery(intent)
        }
    }

    private val speechListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            input.hint = "Google mic: sun raha hoon..."
        }

        override fun onBeginningOfSpeech() {
            retries = 0
        }

        override fun onRmsChanged(rmsdB: Float) {
            wave.push((rmsdB + 2f) / 12f)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            // Mic apne aap band na ho: chup / server masle par khamoshi se dobara sunna.
            if (listening && !usingOffline) {
                when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                        if (continuous || retries < 2) {
                            if (!continuous) retries++
                            scheduleRestart(false)
                            return
                        }
                    }
                    SpeechRecognizer.ERROR_SERVER_DISCONNECTED,
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                        if (retries < (if (continuous) 6 else 2)) {
                            retries++
                            scheduleRestart(true)
                            return
                        }
                    }
                    SpeechRecognizer.ERROR_CLIENT -> {
                        if (continuous) {
                            scheduleRestart(true)
                            return
                        }
                    }
                }
            }
            val wasContinuous = continuous
            continuous = false
            setListeningUi(false)
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "Boss, awaaz samajh nahi aayi. Dobara bolein."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    "Boss, mic ki permission nahi mili."
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                    // Offline mic sirf English samajhta hai: Urdu awaaz par bekar / ghalat likhta hai.
                    if (!urdu && offlineVoice.isReady()) {
                        continuous = wasContinuous
                        startOfflineListening()
                        return
                    }
                    if (urdu) {
                        "Boss, Urdu awaaz ke liye internet chahiye (Google voice service se rabta nahi ho saka). " +
                            "Internet check karein. Offline mic sirf English samajhta hai: upar URDU par tap " +
                            "kar ke ENGLISH kar lein."
                    } else {
                        "Boss, voice recognition ko internet chahiye. Internet ke baghair bolne ke liye " +
                            "⚙ se offline voice model download karein."
                    }
                }
                SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> {
                    recognizer?.destroy()
                    recognizer = null
                    "Boss, voice service dobara connect ho rahi hai. Mic phir se dabayein."
                }
                SpeechRecognizer.ERROR_CLIENT -> return
                else -> "Voice mein masla aaya (code $error). Dobara try karein."
            }
            addMessage(msg, false)
        }

        override fun onResults(results: Bundle?) {
            setListeningUi(false)
            retries = 0
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.let { RomanUrdu.bestAlt(it) }
            input.setText("")
            if (text.isNullOrBlank()) {
                if (continuous) scheduleResume()
                else addMessage("Boss, awaaz samajh nahi aayi. Dobara bolein.", false)
            } else {
                handleUserText(text)
                if (continuous) scheduleResume()
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.let { RomanUrdu.toRoman(it) }
            if (!t.isNullOrBlank()) input.setText(t)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        batteryText = findViewById(R.id.batteryText)
        input = findViewById(R.id.input)
        list = findViewById(R.id.chatList)
        micBtn = findViewById(R.id.micBtn)
        langBtn = findViewById(R.id.langBtn)
        urdu = prefs().getBoolean("urdu", true)
        langBtn.text = if (urdu) "URDU" else "ENGLISH"
        muteBtn = findViewById(R.id.muteBtn)
        core = findViewById(R.id.core)
        wave = findViewById(R.id.wave)

        adapter = ChatAdapter(messages)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        setOnline(hasInternet(cm.getNetworkCapabilities(cm.activeNetwork)))

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("en", "IN"))
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        ttsBusy = true
                    }

                    override fun onDone(utteranceId: String?) {
                        ttsBusy = false
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        ttsBusy = false
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        ttsBusy = false
                    }
                })
                ttsReady = true
            }
        }

        addMessage(
            "Assalam o Alaikum Boss! Main NOVA hoon. Bataiye, kya help kar sakta hoon?",
            false
        )

        findViewById<TextView>(R.id.sendBtn).setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserText(text)
            }
        }

        micBtn.setOnClickListener { onMicClick() }
        findViewById<TextView>(R.id.settingsBtn).setOnClickListener { showSettingsMenu() }

        langBtn.setOnClickListener {
            if (listening || continuous) stopListening()
            urdu = !urdu
            prefs().edit().putBoolean("urdu", urdu).apply()
            langBtn.text = if (urdu) "URDU" else "ENGLISH"
            Toast.makeText(
                this,
                if (urdu) "Voice: Urdu (ur-PK)" else "Voice: English (en-IN)",
                Toast.LENGTH_SHORT
            ).show()
        }

        muteBtn.setOnClickListener {
            muted = !muted
            muteBtn.text = if (muted) "🔇" else "🔊"
            if (muted) tts?.stop()
        }

        micBtn.contentDescription = "Mic"
        handleWakeIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleWakeIntent(intent)
    }

    /** "Hi Nova" se khula to nazar aate hi sunna shuru. */
    private fun handleWakeIntent(i: Intent?) {
        val wakeIntent = i ?: return
        if (!wakeIntent.getBooleanExtra("wake", false)) return
        wakeIntent.removeExtra("wake")
        getSystemService(NotificationManager::class.java).cancel(WakeService.ALERT_ID)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        if (listening) return
        addMessage("Ji Boss, boliye...", false, false)
        handler.postDelayed({
            val ok = ContextCompat.checkSelfPermission(
                this, Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED
            if (!listening && ok) startListening()
        }, 350)
    }

    override fun onStart() {
        super.onStart()
        visible = true
        WakeService.pause()
        if (prefs().getBoolean("wake", false) || prefs().getBoolean("callAssist", false)) {
            try {
                WakeService.start(this)
            } catch (e: Exception) {
            }
            maybeAskBatteryOptimization()
        }
        setOnline(hasInternet(cm.getNetworkCapabilities(cm.activeNetwork)))
        cm.registerDefaultNetworkCallback(netCallback)
        val sticky = registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) updateBattery(sticky)
    }

    override fun onStop() {
        cm.unregisterNetworkCallback(netCallback)
        unregisterReceiver(batteryReceiver)
        if (listening || continuous) stopListening()
        tts?.stop()
        visible = false
        if (prefs().getBoolean("wake", false)) {
            handler.postDelayed({ if (!visible) WakeService.resume() }, 600)
        }
        super.onStop()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        tts?.shutdown()
        offlineVoice.release()
        super.onDestroy()
    }

    private fun onMicClick() {
        if (listening || continuous) {
            stopListening()
            tts?.stop()
            return
        }
        val ok = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (ok) {
            continuous = true
            startListening()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun scheduleRestart(destroy: Boolean) {
        if (destroy) {
            recognizer?.destroy()
            recognizer = null
        }
        handler.postDelayed({
            if ((listening || continuous) && !usingOffline) startListening(false)
        }, 300)
    }

    private fun startListening(userInitiated: Boolean = true) {
        if (userInitiated) {
            retries = 0
            novaFails = 0
        }
        usingNova = false
        if (!online) {
            if (urdu) {
                // Offline English model Urdu ko ghalat angrezi bana deta hai: chalane se behtar hai batana.
                continuous = false
                setListeningUi(false)
                addMessage(
                    "Boss, internet nahi hai. Urdu awaaz ke liye internet chahiye; offline mic sirf " +
                        "English samajhta hai. Upar URDU par tap kar ke ENGLISH kar lein ya internet on karein.",
                    false
                )
                return
            }
            startOfflineListening()
            return
        }
        if (canUseNovaMic()) {
            startNovaMic()
            return
        }
        usingOffline = false
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage(
                "Boss, is phone mein speech recognition service nahi mili. Google app update karein.",
                false
            )
            setListeningUi(false)
            return
        }
        tts?.stop()
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(speechListener)
            }
        } else {
            recognizer?.cancel()
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (urdu) "ur-PK" else "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            // Zara der khamoshi tak sunta rahe, 1-2 second mein band na ho.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 4000L)
        }
        setListeningUi(true)
        recognizer?.startListening(intent)
    }

    private fun stopListening() {
        continuous = false
        handler.removeCallbacks(resumeCheck)
        if (usingNova) nmic?.stop()
        else if (usingOffline) offlineVoice.stop()
        else recognizer?.cancel()
        setListeningUi(false)
    }

    private fun setListeningUi(on: Boolean) {
        listening = on
        core.listening = on
        handler.removeCallbacks(waveTick)
        if (on && usingOffline) handler.post(waveTick)
        micBtn.text = if (on || continuous) "⏹" else "🎙"
        if (!on) {
            wave.clear()
            input.hint = "NOVA se kuch poochein..."
        }
    }

    private val waveTick = object : Runnable {
        override fun run() {
            if (listening && usingOffline) {
                wave.push(0.2f + Math.random().toFloat() * 0.6f)
                handler.postDelayed(this, 90)
            }
        }
    }

    private fun startOfflineListening() {
        usingNova = false
        if (!offlineVoice.isReady()) {
            addMessage(
                "Boss, offline voice ke liye pehle model download karein: upar ⚙ dabayein, " +
                    "phir Offline voice model (~40 MB, Wi-Fi par behtar).",
                false
            )
            return
        }
        tts?.stop()
        usingOffline = true
        setListeningUi(true)
        input.hint = "Sun raha hoon (English)..."
        offlineVoice.start(
            { t -> runOnUiThread { input.setText(t) } },
            { t ->
                runOnUiThread {
                    if (listening) {
                        setListeningUi(false)
                        input.setText("")
                        if (t.isBlank()) {
                            if (continuous) scheduleResume()
                            else addMessage("Boss, awaaz samajh nahi aayi. Dobara bolein.", false)
                        } else {
                            handleUserText(t)
                            if (continuous) scheduleResume()
                        }
                    }
                }
            },
            { m ->
                runOnUiThread {
                    continuous = false
                    setListeningUi(false)
                    addMessage("Boss, offline voice mein masla: $m", false)
                }
            }
        )
    }

    private fun showSettingsMenu() {
        val ready = offlineVoice.isReady()
        val items = arrayOf(
            "Backend secret (Gemini)",
            if (ready) "Offline voice model: tayyar ✅ (delete karein)"
            else "Offline voice model download (~40 MB)",
            "Accessibility permission (lock screen / power menu)",
            "Notification access (notifications parhna)",
            "Saved nicknames (dekhein / delete)",
            if (prefs().getBoolean("auto", true)) "Auto mode: ON ✅ (call/message bina pooche) — band karein"
            else "Auto mode: OFF (pooch kar karega) — on karein",
            if (prefs().getBoolean("wake", false)) "Wake word 'Hi Nova': ON ✅ — band karein"
            else "Wake word 'Hi Nova' on karein (app band ho tab bhi)",
            if (prefs().getBoolean("novamic", false)) "Mic: NOVA mic (AI se likhwata hai) — Google mic par jayein"
            else "Mic: Google mic ✅ — NOVA mic par jayein (tajurbati)",
            if (prefs().getBoolean("callAssist", false)) "Call assistant: ON ✅ — band karein"
            else "Call assistant on karein (NOVA aane wali call uthaye)",
            if (prefs().getBoolean("callUnknownOnly", false)) "Sirf anjaan numbers ki call uthaye: ON ✅ — band karein"
            else "Sirf anjaan numbers ki call uthaye: OFF — on karein",
            "Mera naam (call mein NOVA ye naam bolega): " + (prefs().getString("owner", "") ?: "").ifBlank { "Boss" },
            "Call summaries dekhein"
        )
        AlertDialog.Builder(this)
            .setTitle("NOVA settings")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showSecretDialog()
                    1 -> if (ready) confirmDeleteModel() else downloadOfflineModel()
                    2 -> startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    3 -> startActivity(Intent(android.provider.Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                    4 -> showAliasesDialog()
                    5 -> {
                        val on = !prefs().getBoolean("auto", true)
                        prefs().edit().putBoolean("auto", on).apply()
                        Toast.makeText(
                            this,
                            if (on) "Auto mode ON: call/message seedha hoga"
                            else "Auto mode OFF: pehle poochunga",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    6 -> if (prefs().getBoolean("wake", false)) disableWakeWord() else enableWakeWord()
                    8 -> if (prefs().getBoolean("callAssist", false)) disableCallAssistant() else enableCallAssistant()
                    9 -> {
                        val on = !prefs().getBoolean("callUnknownOnly", false)
                        prefs().edit().putBoolean("callUnknownOnly", on).apply()
                        Toast.makeText(
                            this,
                            if (on) "Sirf anjaan numbers ki call uthaega" else "Har call uthaega",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                    10 -> showOwnerDialog()
                    11 -> showSummariesDialog()
                    7 -> {
                        val on = !prefs().getBoolean("novamic", false)
                        prefs().edit().putBoolean("novamic", on).apply()
                        novaFails = 0
                        Toast.makeText(
                            this,
                            if (on) "NOVA mic ON (tajurbati, internet + secret chahiye)" else "Google mic ON",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
            .show()
    }

    /** Lamba kaam (TikTok, Google, gallery...): NOVA bubble ban kar app ke bahar kaam karta hai. */
    private fun startPhoneTask(goal: String) {
        when {
            NovaAccessibilityService.instance == null -> {
                addMessage("Boss, ye kaam ke liye ⚙ se Accessibility (NOVA AI) on karein.", false)
            }
            !Settings.canDrawOverlays(this) -> {
                addMessage(
                    "Boss, ye kaam bubble se hota hai. Jo screen khuli hai wahan NOVA AI ko " +
                        "'Display over other apps' allow karein, phir dobara bolein.",
                    false
                )
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
            else -> ensurePerm(Manifest.permission.RECORD_AUDIO) {
                val m = "Theek hai Boss, ye kaam main bubble se karta hoon."
                addMessage(m, false, false)
                speak(m)
                stopListening()
                WakeService.runTask(this, goal)
                handler.postDelayed({ moveTaskToBack(true) }, 1500)
            }
        }
    }

    private fun enableWakeWord() {
        if (!offlineVoice.isReady()) {
            addMessage(
                "Boss, wake word ke liye pehle offline voice model download karein " +
                    "(⚙ → Offline voice model, ~40 MB).",
                false
            )
            return
        }
        ensurePerm(Manifest.permission.RECORD_AUDIO) {
            if (Build.VERSION.SDK_INT >= 33) {
                ensurePerm(Manifest.permission.POST_NOTIFICATIONS) { finishWakeSetup() }
            } else {
                finishWakeSetup()
            }
        }
    }

    private fun finishWakeSetup() {
        prefs().edit().putBoolean("wake", true).apply()
        try {
            WakeService.start(this)
        } catch (e: Exception) {
            addMessage("Boss, wake word shuru nahi hua: ${e.message ?: "unknown error"}", false)
            return
        }
        var msg = "Boss, wake word ON ho gaya. App band ho tab bhi \"Hi Nova\" ya \"Hello Nova\" bolein: " +
            "neeche gol NOVA bubble aayega, kaam karega aur ijazat le kar chala jayega."
        if (!Settings.canDrawOverlays(this)) {
            msg += " Zaroori: abhi jo screen khuli hai wahan NOVA AI ko 'Display over other apps' " +
                "allow karein, warna app band hone par khul nahi payegi."
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        addMessage(msg, false, false)
    }

    private fun ensureAll(perms: List<String>, done: () -> Unit) {
        if (perms.isEmpty()) {
            done()
            return
        }
        ensurePerm(perms.first()) { ensureAll(perms.drop(1), done) }
    }

    private fun enableCallAssistant() {
        if ((prefs().getString("secret", "") ?: "").isBlank()) {
            addMessage("Boss, pehle ⚙ mein backend secret daalein, phir Call assistant on karein.", false, false)
            return
        }
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        ensureAll(perms) {
            prefs().edit().putBoolean("callAssist", true).apply()
            try {
                WakeService.start(this)
            } catch (e: Exception) {
                addMessage("Boss, call assistant shuru nahi hua: ${e.message ?: "unknown error"}", false)
                return@ensureAll
            }
            addMessage(
                "Boss, Call assistant ON. Aane wali call agar 12 second tak aap na uthayein to NOVA uthayega, " +
                    "pooche ga \"kya kaam hai\", chhote kaam nipta kar call band karega aur khulasa bata dega. " +
                    "NOVA pehle hi bata deta hai ke wo AI assistant hai. Baat speaker par hoti hai (Android call ki " +
                    "awaaz seedhi nahi deta), is liye pehle kisi dost se test karein.",
                false, false
            )
        }
    }

    private fun disableCallAssistant() {
        prefs().edit().putBoolean("callAssist", false).apply()
        try {
            WakeService.start(this) // service khud dekh legi ke ab kuch chalana nahi
        } catch (e: Exception) {
        }
        Toast.makeText(this, "Call assistant band", Toast.LENGTH_SHORT).show()
    }

    private fun showOwnerDialog() {
        val et = EditText(this).apply {
            hint = "Jaise: Umar"
            setText(prefs().getString("owner", ""))
            setSingleLine()
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Aapka naam")
            .setMessage("Call mein NOVA kahega: \"main <ye naam> ka AI assistant hoon\".")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                prefs().edit().putString("owner", et.text.toString().trim()).apply()
                Toast.makeText(this, "Naam save ho gaya", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSummariesDialog() {
        val list = CallLogStore.list(this).take(15)
        val text = if (list.isEmpty()) "Abhi koi call ka khulasa nahi hai."
        else list.joinToString("\n\n") { CallLogStore.format(it) }
        AlertDialog.Builder(this)
            .setTitle("Call summaries")
            .setMessage(text)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun disableWakeWord() {
        prefs().edit().putBoolean("wake", false).apply()
        WakeService.stop(this)
        Toast.makeText(this, "Wake word band ho gaya", Toast.LENGTH_SHORT).show()
    }

    /** Overlay permission mil jane ke baad ek baar battery optimization hatane ko poochna. */
    private fun maybeAskBatteryOptimization() {
        if (!Settings.canDrawOverlays(this) || prefs().getBoolean("battAsked", false)) return
        val pm = getSystemService(PowerManager::class.java)
        if (pm.isIgnoringBatteryOptimizations(packageName)) return
        prefs().edit().putBoolean("battAsked", true).apply()
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
        }
    }

    private fun showAliasesDialog() {
        val obj = try {
            JSONObject(prefs().getString("aliases", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }
        val keys = obj.keys().asSequence().toList()
        if (keys.isEmpty()) {
            Toast.makeText(
                this,
                "Abhi koi nickname save nahi. Misal: 'Ahmed ko mera friend set karo'",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val items = keys.map { "$it → ${obj.getJSONObject(it).optString("name")}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Saved nicknames (tap karke delete)")
            .setItems(items) { _, i ->
                AlertDialog.Builder(this)
                    .setTitle("Delete karein?")
                    .setMessage(items[i])
                    .setPositiveButton("Delete") { _, _ ->
                        obj.remove(keys[i])
                        prefs().edit().putString("aliases", obj.toString()).apply()
                        Toast.makeText(this, "Delete ho gaya", Toast.LENGTH_SHORT).show()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun confirmDeleteModel() {
        AlertDialog.Builder(this)
            .setTitle("Offline voice model")
            .setMessage("Model delete karein? Dobara download karna padega.")
            .setPositiveButton("Delete") { _, _ ->
                offlineVoice.delete()
                Toast.makeText(this, "Model delete ho gaya", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun downloadOfflineModel() {
        if (!online) {
            addMessage("Boss, model download ke liye internet chahiye.", false)
            return
        }
        addMessage("Offline voice model download ho raha hai... 0%", false)
        val idx = messages.size - 1
        offlineVoice.download(
            { p ->
                runOnUiThread {
                    val t = if (p >= 100) "Model tayyar kiya ja raha hai..."
                    else "Offline voice model download ho raha hai... $p%"
                    messages[idx] = Msg(t, false, false)
                    adapter.notifyItemChanged(idx)
                }
            },
            { ok, err ->
                runOnUiThread {
                    val t = if (ok)
                        "Boss, offline voice model tayyar ✅. Ab internet na ho to bhi English mein " +
                            "bol sakte hain: time, date, battery, help."
                    else "Boss, download nahi hua: $err"
                    messages[idx] = Msg(t, false, false)
                    adapter.notifyItemChanged(idx)
                }
            }
        )
    }

    private fun ensurePerm(perm: String, action: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED) {
            action()
        } else {
            permAction = action
            permLauncher.launch(perm)
        }
    }

    private fun prefs() = getSharedPreferences("nova", Context.MODE_PRIVATE)

    private fun handleUserText(raw: String) {
        val text = RomanUrdu.cleanText(raw)
        addMessage(text, true)
        val userIdx = messages.size - 1

        // "mic band karo" / "bas" bolne se sunna band.
        val words = text.lowercase().split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }
        val stopListen = (words.contains("mic") && words.any { it in setOf("band", "off", "stop", "ruko") }) ||
            (words.contains("listening") && words.contains("stop")) ||
            (words.size <= 3 && words.contains("bas"))
        if (stopListen) {
            stopListening()
            val m = "Theek hai Boss, sunna band kar diya. Dobara mic dabayein."
            addMessage(m, false)
            speak(m)
            return
        }

        if (comm.handle(text, raw)) {
            // Contact / SMS / notification wali baat cloud AI ko history mein nahi jaati.
            messages[userIdx] = Msg(text, true, false)
            return
        }

        val action = PhoneActions.handle(this, text)
        if (action != null) {
            addMessage(action, false, true)
            speak(action)
            return
        }

        val local = LocalCommands.handle(this, text, online)
        if (local != null) {
            addMessage(local, false, true)
            speak(local)
            return
        }

        if (!online) {
            val m = "Boss, abhi internet nahi hai, is liye cloud AI kaam nahi karega. " +
                "Offline mein main time, date, battery jaise commands kar sakta hoon. 'help' bolein."
            addMessage(m, false)
            speak(m)
            return
        }

        val secret = prefs().getString("secret", "") ?: ""
        if (secret.isBlank()) {
            addMessage("Boss, pehle backend ka secret daalein (upar ⚙ button).", false)
            stopListening()
            showSecretDialog()
            return
        }

        val agentWords = text.lowercase().split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }
        if (PhoneAgent.looksLikeTask(agentWords)) {
            startPhoneTask(text)
            return
        }

        addMessage("NOVA soch raha hai...", false)
        val pendingIndex = messages.size - 1
        val histBase = messages.filter { it.inContext }.takeLast(12).dropWhile { !it.fromUser }
        // Urdu script mein bola gaya ho to cloud AI ko asal jumla do (meri Roman andaze se behtar samjhega).
        val history = if (RomanUrdu.hasArabicScript(raw) && histBase.isNotEmpty() && histBase.last().fromUser)
            histBase.dropLast(1) + Msg(raw, true, true)
        else histBase

        cloudBusy++
        NovaApi.chat(history, secret) { ok, reply ->
            runOnUiThread {
                cloudBusy = maxOf(0, cloudBusy - 1)
                messages[pendingIndex] = Msg(reply, false, ok)
                adapter.notifyItemChanged(pendingIndex)
                list.scrollToPosition(pendingIndex)
                if (ok) speak(reply)
            }
        }
    }

    private fun showSecretDialog() {
        val et = EditText(this).apply {
            hint = "NOVA_APP_SECRET"
            setText(prefs().getString("secret", ""))
            setSingleLine()
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Backend secret")
            .setMessage("Vercel mein jo NOVA_APP_SECRET rakha hai, wahi yahan likhein.")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                prefs().edit().putString("secret", et.text.toString().trim()).apply()
                Toast.makeText(this, "Secret save ho gaya", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun speak(text: String) {
        if (muted || !ttsReady) return
        ttsBusy = true
        val r = tts?.speak(text.take(3900), TextToSpeech.QUEUE_FLUSH, null, "nova")
        if (r != TextToSpeech.SUCCESS) ttsBusy = false
    }

    private fun addMessage(text: String, fromUser: Boolean, inContext: Boolean = fromUser) {
        messages.add(Msg(text, fromUser, inContext))
        adapter.notifyItemInserted(messages.size - 1)
        list.scrollToPosition(messages.size - 1)
    }

    private fun setOnline(isOn: Boolean) {
        online = isOn
        statusText.text = if (online) "ONLINE MODE" else "OFFLINE MODE"
        statusText.setTextColor(
            if (online) Color.parseColor("#00B4FF") else Color.parseColor("#FF6E6E")
        )
    }

    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        if (level < 0 || scale <= 0) return
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        batteryText.text = "${level * 100 / scale}%" + if (charging) " ⚡" else ""
    }
}
