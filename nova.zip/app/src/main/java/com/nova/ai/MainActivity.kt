package com.nova.ai

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private val messages = mutableListOf<Msg>()
    private lateinit var adapter: ChatAdapter
    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var statusText: TextView
    private lateinit var batteryText: TextView
    private lateinit var cm: ConnectivityManager
    private val handler = Handler(Looper.getMainLooper())

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            runOnUiThread { setOnline(true) }
        }

        override fun onLost(network: Network) {
            runOnUiThread { setOnline(false) }
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateBattery(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        batteryText = findViewById(R.id.batteryText)
        input = findViewById(R.id.input)
        list = findViewById(R.id.chatList)

        adapter = ChatAdapter(messages)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        setOnline(caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true)

        addMessage(
            "Assalam o Alaikum Boss! Main NOVA hoon. Bataiye, kya help kar sakta hoon?",
            false
        )

        findViewById<TextView>(R.id.sendBtn).setOnClickListener { send() }
        findViewById<TextView>(R.id.micBtn).setOnClickListener {
            Toast.makeText(this, "Mic Phase 2 mein activate hoga", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStart() {
        super.onStart()
        cm.registerDefaultNetworkCallback(netCallback)
        val sticky = registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) updateBattery(sticky)
    }

    override fun onStop() {
        cm.unregisterNetworkCallback(netCallback)
        unregisterReceiver(batteryReceiver)
        super.onStop()
    }

    private fun send() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        addMessage(text, true)
        handler.postDelayed({
            addMessage(
                "Boss, abhi sirf interface ka test ho raha hai. AI jawab Phase 3 mein aayenge.",
                false
            )
        }, 500)
    }

    private fun addMessage(text: String, fromUser: Boolean) {
        messages.add(Msg(text, fromUser))
        adapter.notifyItemInserted(messages.size - 1)
        list.scrollToPosition(messages.size - 1)
    }

    private fun setOnline(online: Boolean) {
        statusText.text = if (online) "ONLINE MODE" else "OFFLINE MODE"
        statusText.setTextColor(if (online) Color.parseColor("#00B4FF") else Color.parseColor("#FF6E6E"))
    }

    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        if (level < 0 || scale <= 0) return
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        batteryText.text = "${level * 100 / scale}%" + if (charging) " ⚡" else ""
    }
}
