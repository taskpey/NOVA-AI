package com.nova.ai

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val messages = mutableListOf<Msg>()
    private lateinit var adapter: ChatAdapter
    private lateinit var list: RecyclerView
    private lateinit var input: EditText
    private lateinit var statusText: TextView
    private lateinit var batteryText: TextView
    private lateinit var micBtn: TextView
    private lateinit var langBtn: TextView
    private lateinit var muteBtn: TextView
    private lateinit var core: NovaCoreView
    private lateinit var wave: WaveformView
    private lateinit var cm: ConnectivityManager
    private val handler = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var urdu = true
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var muted = false
    private var online = false

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startListening()
            else Toast.makeText(this, "Boss, mic ki permission zaroori hai", Toast.LENGTH_LONG).show()
        }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            runOnUiThread { setOnline(true) }
        }

        override fun onLost(network: Network) {
            runOnUiThread { setOnline(false) }
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            updateBattery(intent)
        }
    }

    private val speechListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            input.hint = "Sun raha hoon..."
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            wave.push((rmsdB + 2f) / 12f)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {}

        override fun onError(error: Int) {
            setListeningUi(false)
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "Boss, awaaz samajh nahi aayi. Dobara bolein."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    "Boss, mic ki permission nahi mili."
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Boss, voice recognition ko internet chahiye. Offline voice Phase 4 mein aayegi."
                SpeechRecognizer.ERROR_CLIENT -> return
                else -> "Voice mein masla aaya (code $error). Dobara try karein."
            }
            addMessage(msg, false)
        }

        override fun onResults(results: Bundle?) {
            setListeningUi(false)
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            input.setText("")
            if (text.isNullOrBlank()) {
                addMessage("Boss, awaaz samajh nahi aayi. Dobara bolein.", false)
            } else {
                handleUserText(text)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!t.isNullOrBlank()) input.setText(t)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        batteryText = findViewById(R.id.batteryText)
        input = findViewById(R.id.input)
        list = findViewById(R.id.chatList)
        micBtn = findViewById(R.id.micBtn)
        langBtn = findViewById(R.id.langBtn)
        muteBtn = findViewById(R.id.muteBtn)
        core = findViewById(R.id.core)
        wave = findViewById(R.id.wave)

        adapter = ChatAdapter(messages)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        setOnline(caps?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("en", "IN"))
                ttsReady = true
            }
        }

        addMessage(
            "Assalam o Alaikum Boss! Main NOVA hoon. Bataiye, kya help kar sakta hoon?",
            false
        )

        findViewById<TextView>(R.id.sendBtn).setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                handleUserText(text)
            }
        }

        micBtn.setOnClickListener { onMicClick() }
        findViewById<TextView>(R.id.settingsBtn).setOnClickListener { showSecretDialog() }

        langBtn.setOnClickListener {
            if (listening) stopListening()
            urdu = !urdu
            langBtn.text = if (urdu) "URDU" else "ENGLISH"
            Toast.makeText(
                this,
                if (urdu) "Voice: Urdu (ur-PK)" else "Voice: English (en-IN)",
                Toast.LENGTH_SHORT
            ).show()
        }

        muteBtn.setOnClickListener {
            muted = !muted
            muteBtn.text = if (muted) "🔇" else "🔊"
            if (muted) tts?.stop()
        }
    }

    override fun onStart() {
        super.onStart()
        cm.registerDefaultNetworkCallback(netCallback)
        val sticky = registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (sticky != null) updateBattery(sticky)
    }

    override fun onStop() {
        cm.unregisterNetworkCallback(netCallback)
        unregisterReceiver(batteryReceiver)
        if (listening) stopListening()
        tts?.stop()
        super.onStop()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        tts?.shutdown()
        super.onDestroy()
    }

    private fun onMicClick() {
        if (listening) {
            stopListening()
            return
        }
        val ok = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (ok) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addMessage(
                "Boss, is phone mein speech recognition service nahi mili. Google app update karein.",
                false
            )
            return
        }
        tts?.stop()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(speechListener)
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, if (urdu) "ur-PK" else "en-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        setListeningUi(true)
        recognizer?.startListening(intent)
    }

    private fun stopListening() {
        recognizer?.cancel()
        setListeningUi(false)
    }

    private fun setListeningUi(on: Boolean) {
        listening = on
        core.listening = on
        micBtn.text = if (on) "⏹" else "🎙"
        if (!on) {
            wave.clear()
            input.hint = "NOVA se kuch poochein..."
        }
    }

    private fun prefs() = getSharedPreferences("nova", Context.MODE_PRIVATE)

    private fun handleUserText(text: String) {
        addMessage(text, true)

        if (!online) {
            val m = "Boss, abhi internet nahi hai, is liye cloud AI kaam nahi karega. " +
                "Offline commands Phase 4 mein aayenge."
            addMessage(m, false)
            speak(m)
            return
        }

        val secret = prefs().getString("secret", "") ?: ""
        if (secret.isBlank()) {
            addMessage("Boss, pehle backend ka secret daalein (upar ⚙ button).", false)
            showSecretDialog()
            return
        }

        addMessage("NOVA soch raha hai...", false)
        val pendingIndex = messages.size - 1
        val history = messages.filter { it.inContext }.takeLast(12).dropWhile { !it.fromUser }

        NovaApi.chat(history, secret) { ok, reply ->
            runOnUiThread {
                messages[pendingIndex] = Msg(reply, false, ok)
                adapter.notifyItemChanged(pendingIndex)
                list.scrollToPosition(pendingIndex)
                if (ok) speak(reply)
            }
        }
    }

    private fun showSecretDialog() {
        val et = EditText(this).apply {
            hint = "NOVA_APP_SECRET"
            setText(prefs().getString("secret", ""))
            setSingleLine()
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Backend secret")
            .setMessage("Vercel mein jo NOVA_APP_SECRET rakha hai, wahi yahan likhein.")
            .setView(et)
            .setPositiveButton("Save") { _, _ ->
                prefs().edit().putString("secret", et.text.toString().trim()).apply()
                Toast.makeText(this, "Secret save ho gaya", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun speak(text: String) {
        if (muted || !ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nova")
    }

    private fun addMessage(text: String, fromUser: Boolean, inContext: Boolean = fromUser) {
        messages.add(Msg(text, fromUser, inContext))
        adapter.notifyItemInserted(messages.size - 1)
        list.scrollToPosition(messages.size - 1)
    }

    private fun setOnline(isOn: Boolean) {
        online = isOn
        statusText.text = if (online) "ONLINE MODE" else "OFFLINE MODE"
        statusText.setTextColor(
            if (online) Color.parseColor("#00B4FF") else Color.parseColor("#FF6E6E")
        )
    }

    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        if (level < 0 || scale <= 0) return
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        batteryText.text = "${level * 100 / scale}%" + if (charging) " ⚡" else ""
    }
}
