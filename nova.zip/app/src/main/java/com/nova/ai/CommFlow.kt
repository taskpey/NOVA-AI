package com.nova.ai

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.telecom.TelecomManager
import android.telephony.SmsManager
import androidx.core.app.NotificationManagerCompat
import org.json.JSONObject
import java.util.Locale

/**
 * Phase 6: contacts, call, SMS, WhatsApp, nicknames, notifications.
 * Har sensitive kaam se pehle confirmation poochi jati hai.
 */
class CommFlow(
    private val act: Context,
    private val say: (String) -> Unit,
    private val ensure: (String, () -> Unit) -> Unit
) {
    private enum class Kind { CALL, SMS, WA, ALIAS, WACALL, WAVIDEO, PHOTO }

    private data class Contact(val name: String, val number: String, val key: String)

    private sealed class Pending {
        data class Choice(val kind: Kind, val options: List<Contact>, val nick: String?) : Pending()
        data class ConfirmCall(val c: Contact) : Pending()
        data class ConfirmWa(val c: Contact, val video: Boolean) : Pending()
        data class ConfirmMove(val plan: PhoneSkills.MovePlan) : Pending()
        data class AwaitText(val c: Contact, val via: Kind) : Pending()
        data class ConfirmSend(val c: Contact, val via: Kind, val text: String) : Pending()
    }

    private var pending: Pending? = null
    private var pendingAt = 0L

    private fun setPending(p: Pending?) {
        pending = p
        pendingAt = System.currentTimeMillis()
    }

    companion object {
        // WhatsApp ke liye: local number (0 se shuru) ko is country code mein badalta hai.
        private const val DEFAULT_CC = "92"

        private val stop = setOf(
            "ko", "ka", "ki", "ke", "karo", "kar", "do", "de", "dein", "lagao", "laga", "please", "plz",
            "mujhe", "mera", "meri", "mere", "zara", "na", "aur", "the", "to", "pe", "par", "on", "via",
            "se", "ek", "a", "my", "bhejo", "bhej", "send", "bhejna", "likho", "message", "msg", "sms",
            "paigham", "whatsapp", "watsapp", "call", "dial", "milao", "phone", "number", "contact",
            "contacts", "search", "find", "dhoondo", "dhundo", "dhoondh", "talash", "batao", "bata",
            "dikhao", "dikha", "show", "bhijwao", "open", "kholo", "khol", "kholen", "and", "phir", "then",
            "video", "voice", "audio", "photo", "photos", "pic", "pics", "picture", "image", "tasveer",
            "recent", "new", "naya", "nayi", "latest", "akhri", "aakhri", "last", "or", "aor", "dialer", "kholdo",
            "اینڈ", "کال", "کرو", "کو", "پیغام", "واٹس", "تلاش"
        )
        private val stopAlias = stop + setOf(
            "set", "save", "bana", "banao", "rakho", "as", "karlo", "lo", "le", "lein", "apna", "apni"
        )
        private val possessive = setOf("mera", "meri", "mere", "apna", "apni", "my")
        private val cancelWords = setOf(
            "nahi", "nahin", "no", "cancel", "rehne", "rehnay", "do", "dena", "chor", "chhor", "dein",
            "mat", "stop", "naa", "na", "نہیں", "منسوخ", "رہنے", "دو"
        )
        // Inme se koi bhi aaye to "haan" nahi maana jata (jaise "mat bhejo", "nahi karo").
        private val negWords = setOf(
            "nahi", "nahin", "no", "cancel", "mat", "rehne", "rehnay", "chor", "chhor",
            "نہیں", "منسوخ", "رہنے"
        )
        private val yesWords = setOf(
            "yes", "haan", "han", "ji", "jee", "ok", "okay", "theek", "thik", "bilkul", "kar", "bhej",
            "bhejo", "send", "confirm", "sure", "ہاں", "جی"
        )
    }

    private fun tokens(t: String): List<String> {
        val s = buildString {
            for (c in t.lowercase(Locale.ROOT)) append(if (c.isDigit()) ('0' + Character.digit(c, 10)) else c)
        }
        return s.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotEmpty() }
    }

    private fun isCancel(tk: List<String>) = tk.isNotEmpty() && tk.size <= 3 && tk.all { it in cancelWords }
    private fun isYes(tk: List<String>) =
        tk.isNotEmpty() && tk.size <= 4 && tk.none { it in negWords } && tk.any { it in yesWords }

    // ---------- Nicknames (sirf phone mein, SharedPreferences) ----------
    private fun prefs() = act.getSharedPreferences("nova", Context.MODE_PRIVATE)

    /** Call lag gayi (bubble ko band karne ke liye). */
    var onCallStarted: (() -> Unit)? = null

    /** Koi jawab (contact chunna / message ka text) abhi baqi hai? */
    fun isPending(): Boolean = pending != null

    /** Auto mode ON: call / message bina "haan/nahi" poochay seedha ho jate hain. */
    private fun auto() = prefs().getBoolean("auto", true)

    private fun aliasObj(): JSONObject =
        try {
            JSONObject(prefs().getString("aliases", "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    private fun saveAlias(nick: String, c: Contact) {
        val o = aliasObj()
        o.put(nick, JSONObject().put("name", c.name).put("number", c.number))
        prefs().edit().putString("aliases", o.toString()).apply()
    }

    /** true = mene sambhal liya (jawab chat mein de diya). */
    fun handle(text: String, raw: String = text): Boolean {
        // "call log kholo" / "missed calls" contact ka naam nahi hain: PhoneActions sambhalega.
        run {
            val w = text.lowercase().split(Regex("[^\\p{L}]+"))
            if ("call" in w || "calls" in w) {
                if (w.any { it == "log" || it == "logs" || it == "history" || it == "missed" }) return false
            }
        }
        if (pending != null && System.currentTimeMillis() - pendingAt > 60_000) pending = null
        val tk = tokens(text)

        val p = pending
        if (p != null && handlePending(p, raw, tk)) return true

        if (tk.isEmpty() || tk.size > 20) return false
        fun has(vararg w: String) = w.any { it in tk }
        fun nameOf(): String? {
            val n = tk.filter { it !in stop }
            return if (n.size > 3) null else n.joinToString(" ").trim()
        }

        val sendVerb = has("bhejo", "bhej", "bhejna", "send", "likho", "karo", "kar", "bhijwao")
        val openVerb = has("open", "opn", "kholo", "kholen", "khol", "launch")
        val isMsg = (has("message", "msg", "sms", "paigham", "پیغام") || has("whatsapp", "watsapp", "واٹس")) &&
            sendVerb && (!openVerb || has("message", "msg", "sms", "paigham", "پیغام"))
        val aliasSet = has("set", "save", "bana", "banao", "rakho") &&
            tk.any { it in possessive } && has("ko", "as") && tk.size >= 4 &&
            !has("alarm", "timer", "reminder", "remind", "yaad", "dilao", "brightness", "volume")
        val aliasList = has("nickname", "nicknames", "alias", "aliases", "favorite", "favorites", "favourite") &&
            has("dikhao", "show", "list", "batao", "kaun", "kon")
        val notif = (has("notification", "notifications", "notif", "notifs", "نوٹیفکیشن") &&
            has("parho", "padho", "padh", "read", "sunao", "dikhao", "batao", "bata", "show", "kya", "koi", "check")) ||
            (has("naya", "new", "koi") && has("message", "messages") &&
                has("aya", "aaya", "aye", "aaye", "kya", "check") && !sendVerb)

        return when {
            has("call", "کال") && has("end", "cut", "kaat", "kaato", "katt", "band", "disconnect", "khatam", "ختم") -> {
                endCall()
                true
            }

            aliasSet -> {
                setAlias(tk)
                true
            }

            aliasList -> {
                listAliases()
                true
            }

            notif -> {
                readNotifications()
                true
            }

            (has("search", "find", "dhoondo", "dhundo", "dhoondh", "talash", "تلاش") && has("contact", "contacts")) ||
                (has("number") && has("batao", "bata", "dikhao", "dikha", "show")) -> {
                val n = nameOf() ?: return false
                if (n.isBlank()) say("Boss, kiska contact dhoondna hai? Misal: 'search contact Ahmed'.")
                else lookup(null, n)
                true
            }

            has("photo", "picture", "pic", "image", "tasveer", "تصویر") &&
                has("bhejo", "bhej", "send", "bhijwao", "share") -> {
                val n = nameOf() ?: return false
                if (n.isBlank()) say("Boss, photo kisko bhejni hai? Misal: 'Ali ko meri recent photo bhejo'.")
                else lookup(Kind.PHOTO, n)
                true
            }

            has("screenshot", "screenshots") &&
                has("delete", "hatao", "mitao", "mita", "remove", "uda", "udao", "clear") -> {
                deleteScreenshots(has("all", "saare", "sare", "tamam", "sab"))
                true
            }

            has("download", "downloads") &&
                has("folder", "folders", "organize", "sort", "alag", "convert", "move", "safai", "arrange") -> {
                organizeDownloads()
                true
            }

            has("whatsapp", "watsapp", "واٹس") && has("call", "کال") -> {
                val n = nameOf() ?: return false
                val kind = if (has("video")) Kind.WAVIDEO else Kind.WACALL
                if (n.isBlank()) say("Boss, kis ko WhatsApp call karni hai? Misal: 'WhatsApp call Ahmed'.")
                else lookup(kind, n)
                true
            }

            isMsg -> {
                val via = if (has("whatsapp", "watsapp", "واٹس")) Kind.WA else Kind.SMS
                val inline = extractInline(text)
                if (inline != null) {
                    // "Kainat ko Hi ka message bhejo" / "Ahmed ko message bhejo ke main late hoon"
                    val words = inline.first.split(Regex("\\s+")).filter { it.isNotEmpty() && it.lowercase() !in stop }
                    if (words.size > 3) return false
                    val n = words.joinToString(" ")
                    if (n.isBlank()) say("Boss, kis ko? Misal: 'Ahmed ko message bhejo'.")
                    else lookup(via, n, inline.second)
                } else {
                    val n = nameOf() ?: return false
                    if (n.isBlank()) say("Boss, kis ko? Misal: 'Ahmed ko message bhejo'.")
                    else lookup(via, n)
                }
                true
            }

            has("call", "کال") && tk.size <= 9 -> {
                val n = nameOf() ?: return false
                if (n.isBlank()) say("Boss, kis ko call karni hai? Misal: 'Ahmed ko call karo'.")
                else lookup(Kind.CALL, n)
                true
            }

            else -> false
        }
    }

    private fun handlePending(p: Pending, text: String, tk: List<String>): Boolean {
        // "do" ka matlab 2 bhi hai aur "rehne do" bhi: Choice mein pehle number dekho.
        val cancel = if (p is Pending.Choice && pickIndex(tk, p.options.size) != null) false
        else (isCancel(tk) ||
            ((p is Pending.ConfirmCall || p is Pending.ConfirmSend || p is Pending.ConfirmWa ||
                p is Pending.ConfirmMove) &&
                tk.any { it in negWords }))
        if (cancel) {
            pending = null
            say("Theek hai Boss, cancel kar diya.")
            return true
        }
        when (p) {
            is Pending.Choice -> {
                val i = pickIndex(tk, p.options.size)
                if (i == null) {
                    pending = null
                    return false
                }
                pending = null
                proceed(p.kind, p.options[i], p.nick)
            }

            is Pending.ConfirmCall -> {
                pending = null
                if (isYes(tk)) doCall(p.c) else return false
            }

            is Pending.ConfirmWa -> {
                pending = null
                if (isYes(tk)) doWaCall(p.c, p.video) else return false
            }

            is Pending.AwaitText -> {
                val msg = text.trim()
                if (auto()) {
                    pending = null
                    if (p.via == Kind.WA) sendWhatsApp(p.c, msg) else sendSms(p.c, msg)
                } else {
                    setPending(Pending.ConfirmSend(p.c, p.via, msg))
                    val how = if (p.via == Kind.WA) "WhatsApp par" else "SMS se"
                    say("Boss, ye message hai:\n\"$msg\"\n${p.c.name} ko $how bhejun? (haan / nahi)")
                }
            }

            is Pending.ConfirmSend -> {
                pending = null
                if (isYes(tk)) {
                    when (p.via) {
                        Kind.WA -> sendWhatsApp(p.c, p.text)
                        Kind.PHOTO -> sendPhoto(p.c)
                        else -> sendSms(p.c, p.text)
                    }
                } else return false
            }

            is Pending.ConfirmMove -> {
                pending = null
                if (isYes(tk)) runMove(p.plan) else return false
            }
        }
        return true
    }

    private fun pickIndex(tk: List<String>, n: Int): Int? {
        val map = mapOf(
            "1" to 1, "ek" to 1, "pehla" to 1, "pehle" to 1, "first" to 1, "one" to 1,
            "2" to 2, "do" to 2, "dusra" to 2, "doosra" to 2, "second" to 2, "two" to 2,
            "3" to 3, "teen" to 3, "tisra" to 3, "third" to 3, "three" to 3,
            "4" to 4, "char" to 4, "chautha" to 4, "four" to 4,
            "5" to 5, "paanch" to 5, "panch" to 5, "fifth" to 5, "five" to 5
        )
        for (t in tk) {
            val v = map[t] ?: continue
            if (v in 1..n) return v - 1
        }
        return null
    }

    /** Jumle mein hi message likha ho to (naam wala hissa, message) wapas karta hai. */
    private fun extractInline(t: String): Pair<String, String>? {
        val s = t.trim()
        Regex("^(.*?)\\s+ko\\s+(.+?)\\s+(?:ka|ki|ke)\\s+(?:message|msg|sms|paigham)\\b", RegexOption.IGNORE_CASE)
            .find(s)?.let { return it.groupValues[1] to it.groupValues[2].trim() }
        Regex(
            "^(.*?)\\b(?:message|msg|sms|paigham)\\s+(?:bhejo|bhej\\s*do|bhejna|karo|kar\\s*do|likho)\\s+(?:ke|ki|k)\\s+(.+)$",
            RegexOption.IGNORE_CASE
        ).find(s)?.let { return it.groupValues[1] to it.groupValues[2].trim() }
        return null
    }

    private fun proceed(kind: Kind, c: Contact, nick: String?) {
        when (kind) {
            Kind.CALL -> {
                if (auto()) {
                    doCall(c)
                } else {
                    setPending(Pending.ConfirmCall(c))
                    say("Boss, ${c.name} (${c.number}) ko call karun? (haan / nahi)")
                }
            }

            Kind.PHOTO -> {
                if (auto()) {
                    sendPhoto(c)
                } else {
                    setPending(Pending.ConfirmSend(c, Kind.PHOTO, ""))
                    say("Boss, ${c.name} ko WhatsApp par recent photo bhejun? (haan / nahi)")
                }
            }

            Kind.WACALL, Kind.WAVIDEO -> {
                val video = kind == Kind.WAVIDEO
                if (auto()) {
                    doWaCall(c, video)
                } else {
                    setPending(Pending.ConfirmWa(c, video))
                    say("Boss, ${c.name} ko WhatsApp ${if (video) "video " else ""}call karun? (haan / nahi)")
                }
            }

            Kind.ALIAS -> {
                val n = nick ?: "friend"
                saveAlias(n, c)
                say("Boss, ${c.name} ab aapka '$n' hai. Ab kahein: 'call my $n'.")
            }

            else -> {
                val body = nick?.trim().orEmpty()
                if (body.isNotEmpty()) {
                    // Message jumle mein hi tha: dobara poochne ki zaroorat nahi.
                    if (auto()) {
                        if (kind == Kind.WA) sendWhatsApp(c, body) else sendSms(c, body)
                    } else {
                        setPending(Pending.ConfirmSend(c, kind, body))
                        val how = if (kind == Kind.WA) "WhatsApp par" else "SMS se"
                        say("Boss, ye message hai:\n\"$body\"\n${c.name} ko $how bhejun? (haan / nahi)")
                    }
                } else {
                    setPending(Pending.AwaitText(c, kind))
                    say("Boss, ${c.name} ko kya message bhejna hai?")
                }
            }
        }
    }

    // ---------- Nicknames ----------
    private fun setAlias(tk: List<String>) {
        val idx = tk.indexOfFirst { it in possessive }
        val nick = tk.getOrNull(idx + 1)
        val rest = tk.filterIndexed { i, _ -> i != idx && i != idx + 1 }
            .filter { it !in stopAlias }
            .joinToString(" ")
        if (nick == null || nick in stopAlias || rest.isBlank()) {
            say("Boss, aise kahein: 'Ahmed ko mera friend set karo'.")
            return
        }
        lookup(Kind.ALIAS, rest, nick)
    }

    private fun listAliases() {
        val o = aliasObj()
        val keys = o.keys().asSequence().toList()
        if (keys.isEmpty()) {
            say("Boss, abhi koi nickname save nahi hai. Misal: 'Ahmed ko mera friend set karo'.")
        } else {
            say(
                "Boss, aapke saved nicknames:\n" + keys.joinToString("\n") {
                    "$it → ${o.getJSONObject(it).optString("name")}"
                }
            )
        }
    }

    // ---------- Notifications ----------
    private fun readNotifications() {
        if (!NotificationManagerCompat.getEnabledListenerPackages(act).contains(act.packageName)) {
            act.launch(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            say(
                "Boss, notifications parhne ke liye 'Notification access' allow karna hota hai. " +
                    "Settings khol di hai: NOVA AI ko on karein. (Switch band ho to Settings → Apps → " +
                    "NOVA AI → ⋮ → Allow restricted settings.) Phir dobara kahein."
            )
            return
        }
        val items = NovaNotificationService.recent(5)
        if (items.isEmpty()) {
            say("Boss, abhi koi notification nahi hai.")
        } else {
            say(
                "Boss, aakhri ${items.size} notifications:\n" +
                    items.mapIndexed { i, n -> "${i + 1}) ${n.app} — ${n.title}: ${n.text}" }.joinToString("\n")
            )
        }
    }

    // ---------- Contacts ----------
    private fun lookup(kind: Kind?, name: String, nick: String? = null) {
        val waKind = kind == Kind.WACALL || kind == Kind.WAVIDEO
        var query = name
        if (kind != null && (kind == Kind.CALL || kind == Kind.SMS || kind == Kind.WA || kind == Kind.PHOTO || waKind)) {
            val al = aliasObj()
            if (al.has(name)) {
                val o = al.getJSONObject(name)
                if (waKind) {
                    query = o.optString("name")
                } else {
                    proceed(kind, Contact(o.optString("name"), o.optString("number"), ""), nick)
                    return
                }
            }
        }
        ensure(Manifest.permission.READ_CONTACTS) {
            val r = if (waKind) findWhatsAppContacts(query, kind == Kind.WAVIDEO) else findContacts(query)
            when {
                r.isEmpty() -> say(
                    if (waKind) "Boss, '$name' naam ka WhatsApp wala contact nahi mila."
                    else "Boss, '$name' naam ka koi contact nahi mila. (Contact ka naam jaise phone mein likha hai, waise bolein.)"
                )
                kind == null -> say("Boss, ye contacts mile:\n" + r.joinToString("\n") { "${it.name}: ${it.number}" })
                r.size == 1 -> proceed(kind, r[0], nick)
                else -> {
                    setPending(Pending.Choice(kind, r, nick))
                    say(
                        "Boss, ye contacts mile:\n" +
                            r.mapIndexed { i, c -> "${i + 1}) ${c.name}${if (c.number.isBlank()) "" else ": " + c.number}" }.joinToString("\n") +
                            "\nKaun sa? Number bolein ya 'nahi' kahein."
                    )
                }
            }
        }
    }

    /** Sabse achhe match wale items (exact > naam ki awaaz > mil-julta). */
    private fun <T> bestMatches(query: String, items: List<T>, nameOf: (T) -> String): List<T> {
        val scored = items.map { it to RomanUrdu.matchScore(query, nameOf(it)) }.filter { it.second > 0 }
        if (scored.isEmpty()) return emptyList()
        val best = scored.maxOf { it.second }
        return scored.filter { it.second == best }.map { it.first }
    }

    private fun findContacts(name: String): List<Contact> {
        val all = mutableListOf<Contact>()
        val phone = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val nameCol = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME
        val numCol = ContactsContract.CommonDataKinds.Phone.NUMBER
        val c = act.contentResolver.query(phone, arrayOf(nameCol, numCol), null, null, "$nameCol ASC")
        c?.use {
            while (it.moveToNext() && all.size < 8000) {
                val n = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                all.add(Contact(n, num, num.filter { ch -> ch.isDigit() }.takeLast(9)))
            }
        }
        val list = mutableListOf<Contact>()
        val found = bestMatches(name, all) { it.name }
        for (x in found) {
            if (list.none { y -> y.key == x.key }) list.add(x)
            if (list.size >= 5) break
        }
        return list
    }

    /** WhatsApp ke contacts (jin ke paas WhatsApp call ka data row hai). key = data row id. */
    private fun findWhatsAppContacts(name: String, video: Boolean): List<Contact> {
        val mime = if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
        else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        val all = mutableListOf<Contact>()
        val c = act.contentResolver.query(
            ContactsContract.Data.CONTENT_URI,
            arrayOf(ContactsContract.Data._ID, ContactsContract.Data.DISPLAY_NAME),
            "${ContactsContract.Data.MIMETYPE} = ?", arrayOf(mime), null
        )
        c?.use {
            while (it.moveToNext() && all.size < 8000) {
                val id = it.getString(0) ?: continue
                val n = it.getString(1) ?: continue
                all.add(Contact(n, "", id))
            }
        }
        return bestMatches(name, all) { it.name }.distinctBy { it.name }.take(5)
    }

    // ---------- Actions (sirf confirmation ke baad) ----------
    private fun doCall(c: Contact) {
        ensure(Manifest.permission.CALL_PHONE) {
            try {
                act.launch(Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(c.number))))
                say("Boss, ${c.name} ko call mila raha hoon.")
                onCallStarted?.invoke()
            } catch (e: Exception) {
                say("Boss, call nahi ho saki: ${e.message ?: "unknown error"}")
            }
        }
    }

    private fun sendPhoto(c: Contact) {
        ensure(PhoneSkills.imagesPermission()) {
            val uri = PhoneSkills.latestPhoto(act)
            if (uri == null) {
                say("Boss, gallery mein koi photo nahi mili.")
                return@ensure
            }
            try {
                val i = Intent(Intent.ACTION_SEND).apply {
                    type = "image/*"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    setPackage("com.whatsapp")
                    putExtra("jid", waNumber(c.number) + "@s.whatsapp.net")
                    clipData = android.content.ClipData.newRawUri("", uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                act.launch(i)
                if (auto() && NovaAccessibilityService.instance != null) {
                    NovaAccessibilityService.armSend()
                    say("Boss, ${c.name} ko sabse nayi photo WhatsApp par bhej raha hoon.")
                } else {
                    say("Boss, ${c.name} ki chat mein photo laga di hai. Send ka button dabayein.")
                }
            } catch (e: Exception) {
                say("Boss, photo nahi bhej saka: ${e.message ?: "WhatsApp nahi mili"}")
            }
        }
    }

    private fun deleteScreenshots(all: Boolean) {
        ensure(PhoneSkills.imagesPermission()) {
            val list = PhoneSkills.screenshots(act, all)
            if (list.isEmpty()) {
                say("Boss, koi screenshot nahi mila.")
                return@ensure
            }
            val i = Intent(act, ActionActivity::class.java)
                .putParcelableArrayListExtra("uris", ArrayList(list))
            act.launch(i)
            say(
                "Boss, ${if (all) "${list.size} screenshots" else "sabse naya screenshot"} delete karne ki " +
                    "ijazat screen par aayi hai, 'Allow' dabayein."
            )
        }
    }

    private fun organizeDownloads() {
        if (!PhoneSkills.hasAllFilesAccess()) {
            say(
                "Boss, Downloads ki files hilane ke liye 'All files access' chahiye. Jo screen khuli hai " +
                    "wahan NOVA AI ko allow karein, phir dobara bolein."
            )
            try {
                act.launch(
                    Intent(
                        android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + act.packageName)
                    )
                )
            } catch (e: Exception) {
            }
            return
        }
        val plan = PhoneSkills.planDownloads()
        if (plan == null || plan.moves.isEmpty()) {
            say("Boss, Downloads mein koi file nahi mili.")
            return
        }
        val parts = plan.counts.entries.joinToString(", ") { "${it.key}: ${it.value}" }
        setPending(Pending.ConfirmMove(plan))
        say(
            "Boss, Downloads mein ${plan.moves.size} files hain ($parts). Inhein Downloads ke andar " +
                "type ke hisaab se folders mein rakh dun? (haan / nahi)"
        )
    }

    private fun runMove(plan: PhoneSkills.MovePlan) {
        val n = PhoneSkills.executeMoves(act, plan)
        say("Boss, ${plan.moves.size} mein se $n files folders mein chali gayin.")
    }

    private fun doWaCall(c: Contact, video: Boolean) {
        val mime = if (video) "vnd.android.cursor.item/vnd.com.whatsapp.video.call"
        else "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"
        // WhatsApp ka call screen CALL_PHONE permission maangta hai, pehle wo lein.
        ensure(Manifest.permission.CALL_PHONE) {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                    .setDataAndType(Uri.parse("content://com.android.contacts/data/${c.key}"), mime)
                    .setPackage("com.whatsapp")
                act.launch(i)
                say("Boss, ${c.name} ko WhatsApp ${if (video) "video " else ""}call mila raha hoon.")
                onCallStarted?.invoke()
            } catch (e: Exception) {
                say("Boss, WhatsApp call nahi ho saki: ${e.message ?: "unknown error"}")
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun sendSms(c: Contact, text: String) {
        ensure(Manifest.permission.SEND_SMS) {
            try {
                val sm: SmsManager = if (Build.VERSION.SDK_INT >= 31)
                    act.getSystemService(SmsManager::class.java)
                else SmsManager.getDefault()
                val parts = sm.divideMessage(text)
                if (parts.size > 1) sm.sendMultipartTextMessage(c.number, null, parts, null, null)
                else sm.sendTextMessage(c.number, null, text, null, null)
                say("Boss, ${c.name} ko message bhej diya. (Pohanchna SIM ke balance aur network par depend karta hai.)")
            } catch (e: Exception) {
                say("Boss, message nahi gaya: ${e.message ?: "unknown error"}")
            }
        }
    }

    private fun waNumber(raw: String): String {
        val digits = raw.filter { it.isDigit() }
        return when {
            raw.trim().startsWith("+") -> digits
            digits.startsWith("00") -> digits.drop(2)
            digits.startsWith("0") -> DEFAULT_CC + digits.drop(1)
            else -> digits
        }
    }

    private fun sendWhatsApp(c: Contact, text: String) {
        val uri = Uri.parse("https://wa.me/${waNumber(c.number)}?text=" + Uri.encode(text))
        try {
            try {
                act.launch(Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp"))
            } catch (e: android.content.ActivityNotFoundException) {
                act.launch(Intent(Intent.ACTION_VIEW, uri))
            }
            if (auto()) {
                if (NovaAccessibilityService.instance != null) {
                    NovaAccessibilityService.armSend()
                    say("Boss, ${c.name} ko WhatsApp par message bhej raha hoon.")
                } else {
                    say(
                        "Boss, WhatsApp khol diya, message likha hua hai. Khud bhejne ke liye ⚙ se " +
                            "Accessibility on karein; abhi Send ka button dabayein."
                    )
                }
            } else {
                say("Boss, WhatsApp khol diya, message likha hua hai. Bas send ka button dabayein.")
            }
        } catch (e: Exception) {
            say("Boss, WhatsApp nahi khul saka: ${e.message ?: "unknown error"}")
        }
    }

    private fun endCall() {
        if (Build.VERSION.SDK_INT < 28) {
            say("Boss, call khatam karne ke liye Android 9 ya naya chahiye.")
            return
        }
        ensure(Manifest.permission.ANSWER_PHONE_CALLS) {
            val tm = act.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            val ok = try {
                tm.endCall()
            } catch (e: SecurityException) {
                false
            }
            say(if (ok) "Boss, call khatam kar di." else "Boss, koi chalti hui call nahi mili.")
        }
    }
}
