package com.nova.ai

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.ContactsContract

/**
 * Contacts ke naam (sirf naam, number nahi). Ye awaaz likhne wale AI ko diye jate hain
 * taake wo "Zain", "Imran New 428" jaise naam sahi likhe, bilkul Siri ki tarah.
 */
object ContactHints {
    private var cache = ""
    private var at = 0L

    /** Background thread se bulayen (contacts parhne mein thora waqt lagta hai). */
    @Synchronized
    fun get(ctx: Context): String {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return ""
        }
        val now = System.currentTimeMillis()
        if (cache.isNotEmpty() && now - at < 10 * 60_000L) return cache
        val names = LinkedHashSet<String>()
        try {
            ctx.contentResolver.query(
                ContactsContract.Contacts.CONTENT_URI,
                arrayOf(ContactsContract.Contacts.DISPLAY_NAME),
                "${ContactsContract.Contacts.HAS_PHONE_NUMBER} = 1",
                null,
                "${ContactsContract.Contacts.DISPLAY_NAME} ASC"
            )?.use { c ->
                while (c.moveToNext() && names.size < 400) {
                    val n = c.getString(0)?.trim().orEmpty()
                    if (n.isNotEmpty() && n.length <= 40) names.add(n)
                }
            }
        } catch (e: Exception) {
        }
        cache = names.joinToString(", ").take(3500)
        at = now
        return cache
    }
}
