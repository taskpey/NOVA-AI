package com.nova.ai

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import java.util.Locale

/** Phone control commands (Phase 5, hissa 1): koi khaas permission nahi chahiye. */
object PhoneActions {

    private var torchOn = false

    private fun norm(t: String): String = buildString {
        for (c in t.lowercase(Locale.ROOT)) {
            append(if (c.isDigit()) ('0' + Character.digit(c, 10)) else c)
        }
    }

    fun handle(a: Activity, text: String): String? {
        val raw = norm(text).replace("flash light", "flashlight").replace("flash-light", "flashlight")
        val tk = raw.split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }
        if (tk.isEmpty() || tk.size > 12) return null
        fun has(vararg w: String) = w.any { it in tk }

        val openVerb = has(
            "open", "opn", "opne", "oen", "kholo", "kholen", "khol", "kholiye", "launch", "chalao",
            "کھولو", "کھولیں", "کھول"
        )
        val mediaWords = has("music", "gana", "gaana", "song", "gane", "media", "track", "میوزک", "گانا")
        val isTimer = has("timer", "ٹائمر") ||
            (has("alarm", "الارم") &&
                has("minute", "minutes", "min", "منٹ", "baad", "hour", "hours", "ghanta", "ghante"))

        // Sawal poochne wale jumlon par lock/power jaise kaam trigger na hon.
        val isQuestion = has(
            "kaise", "kese", "kaisay", "kyun", "kyon", "why", "how", "what", "kya", "explain",
            "samjhao", "matlab", "meaning", "batao", "bata", "kaun", "kon", "کیا", "کیسے"
        )
        val onOff = has("on", "off", "jalao", "jala", "bujhao", "bujha", "band", "chalao", "chalu", "روشن", "بند")

        return try {
            when {
                has("torch", "flashlight", "tarch", "tourch", "ٹارچ") ||
                    (has("flash", "light", "lite") && onOff && tk.size <= 5 && !isQuestion) ->
                    flashlight(a, tk)
                has("remind", "reminder") ||
                    (has("yaad") && has("dilao", "dila", "dilana", "dilaana")) -> reminder(a, raw, tk)
                isTimer -> timer(a, raw, tk)
                has("alarm", "الارم") -> alarm(a, raw, tk)
                has("volume", "awaaz", "آواز") -> volume(a, tk)
                has("brightness", "brightnes", "roshni", "روشنی") -> brightness(a, raw, tk)
                !isQuestion && (has("shutdown", "restart", "reboot", "poweroff") ||
                    (has("shut") && has("down")) ||
                    (has("power") && has("menu", "off", "dialog"))) -> powerMenu(a)
                !isQuestion && has("lock", "tala", "لاک") && !has("unlock") &&
                    has("screen", "phone", "mobile", "tala", "لاک", "karo", "kar", "lagao", "do", "now") -> lockScreen(a)
                mediaWords -> media(a, tk)
                has("settings", "setting", "ترتیبات") ||
                    (openVerb && (has("wifi", "bluetooth", "location") || (has("wi") && has("fi")))) ->
                    settings(a, tk)
                openVerb && has("camera", "کیمرہ") -> camera(a)
                openVerb && has("contacts", "contact") -> contacts(a)
                openVerb -> openApp(a, tk)
                else -> null
            }
        } catch (e: Exception) {
            "Boss, ye kaam nahi ho saka: ${e.message ?: "unknown error"}"
        }
    }

    // ---------- Flashlight ----------
    private fun flashlight(a: Activity, tk: List<String>): String {
        fun has(vararg w: String) = w.any { it in tk }
        val off = has("off", "band", "bujhao", "bujha", "بند", "بجھاؤ")
        val on = has("on", "jalao", "jala", "chalao", "chalu", "chala", "kholo", "start", "روشن", "جلاؤ")
        val state = when {
            off -> false
            on -> true
            else -> !torchOn
        }
        val cm = a.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Boss, is phone mein flashlight nahi mili."
        cm.setTorchMode(id, state)
        torchOn = state
        return if (state) "Boss, flashlight on kar di." else "Boss, flashlight band kar di."
    }

    // ---------- Alarm ----------
    private fun alarm(
        a: Activity, raw: String, tk: List<String>,
        label: String = "NOVA", needVerb: Boolean = true, rem: Boolean = false
    ): String? {
        fun has(vararg w: String) = w.any { it in tk }
        if (needVerb && !has("lagao", "laga", "lagana", "set", "bana", "banao", "rakho", "create", "لگاؤ", "لگا", "لگانا"))
            return null
        val m = Regex("(\\d{1,2})(?:\\s*[:.]\\s*|\\s+)(\\d{2})").find(raw)
            ?: Regex("(\\d{1,2})").find(raw)
            ?: return "Boss, kis waqt ka alarm lagana hai? Misal: 'subah 7:30 ka alarm lagao'."
        var hour = m.groupValues[1].toInt()
        val min = if (m.groupValues.size > 2 && m.groupValues[2].isNotEmpty()) m.groupValues[2].toInt() else 0
        val night = has("raat", "night")
        if (night) {
            // raat 12 = aadhi raat (00:00), raat 1-5 = subah ke chhote ghante, raat 6-11 = shaam/raat
            if (hour == 12) hour = 0 else if (hour in 6..11) hour += 12
        } else if (has("pm", "shaam", "sham", "dopahar", "evening") && hour in 1..11) {
            hour += 12
        }
        if (has("am", "subah", "morning", "savere") && hour == 12) hour = 0
        if (hour > 23 || min > 59)
            return "Boss, alarm ka waqt samajh nahi aaya. Misal: 'subah 7:30 ka alarm lagao'."

        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, min)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        a.startActivity(i)
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        val ampm = if (hour < 12) "AM" else "PM"
        val t = "$h12:${"%02d".format(min)} $ampm"
        return if (rem) "Boss, $t par yaad dila dunga: $label. Clock app mein check kar lein."
        else "Boss, $t ka alarm set kar diya. Clock app mein check kar lein."
    }

    // ---------- Timer ----------
    private fun timer(
        a: Activity, raw: String, tk: List<String>,
        label: String = "NOVA", rem: Boolean = false
    ): String? {
        fun has(vararg w: String) = w.any { it in tk }
        val n = Regex("(\\d+)").find(raw)?.value?.toIntOrNull() ?: return null
        val (secs, unit) = when {
            has("hour", "hours", "ghanta", "ghante", "گھنٹہ", "گھنٹے") -> n * 3600 to "ghante"
            has("second", "seconds", "sec", "سیکنڈ") -> n to "second"
            else -> n * 60 to "minute"
        }
        if (secs !in 1..86400) return "Boss, timer 1 second se 24 ghante ke beech hona chahiye."
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, secs)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        a.startActivity(i)
        return if (rem) "Boss, $n $unit baad yaad dila dunga: $label."
        else "Boss, $n $unit ka timer shuru kar diya."
    }

    // ---------- Reminder ----------
    private fun reminder(a: Activity, raw: String, tk: List<String>): String? {
        fun has(vararg w: String) = w.any { it in tk }
        val relative = has("minute", "minutes", "min", "منٹ", "hour", "hours", "ghanta", "ghante", "second", "sec") &&
            has("baad", "bad", "mein", "in", "after")
        val remStop = setOf(
            "remind", "reminder", "me", "yaad", "dilao", "dila", "dilana", "dilaana", "mujhe", "mujhy", "muje",
            "mera", "meri", "aur", "please", "plz", "minute", "minutes", "min", "hour", "hours", "ghanta",
            "ghante", "second", "sec", "baad", "bad", "mein", "in", "after", "baje", "subah", "shaam", "sham",
            "raat", "dopahar", "am", "pm", "at", "ko", "ke", "ki", "ka", "to", "ye", "yeh", "kar", "karo",
            "do", "de", "that", "liye", "about", "منٹ", "یاد"
        )
        val label = tk.filter { it !in remStop }.joinToString(" ").ifBlank { "Reminder" }.take(60)
        return when {
            relative -> timer(a, raw, tk, label, true)
            Regex("\\d").containsMatchIn(raw) -> alarm(a, raw, tk, label, false, true)
            else -> "Boss, kab yaad dilana hai? Misal: '10 minute baad yaad dilao ke chai banani hai'."
        }
    }

    // ---------- Accessibility: lock screen / power menu ----------
    private fun a11y(a: Activity, action: Int, doing: String): String {
        val svc = NovaAccessibilityService.instance
        if (svc == null) {
            a.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return "Boss, iske liye Accessibility permission chahiye. Settings khol di hai: " +
                "NOVA AI dhoondh kar on karein (Installed ya Downloaded apps mein hota hai). " +
                "Phir dobara kahein."
        }
        svc.performGlobalAction(action)
        return doing
    }

    private fun lockScreen(a: Activity): String {
        if (Build.VERSION.SDK_INT < 28) return "Boss, screen lock ke liye Android 9 ya naya chahiye."
        return a11y(a, AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, "Boss, screen lock kar raha hoon.")
    }

    private fun powerMenu(a: Activity): String =
        a11y(
            a, AccessibilityService.GLOBAL_ACTION_POWER_DIALOG,
            "Boss, power menu khol diya. Band ya restart aap khud dabayein, normal app ye zabardasti nahi kar sakti."
        )

    // ---------- Brightness ----------
    private fun brightness(a: Activity, raw: String, tk: List<String>): String? {
        fun has(vararg w: String) = w.any { it in tk }
        if (!Settings.System.canWrite(a)) {
            a.startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + a.packageName))
            )
            return "Boss, brightness badalne ke liye 'Modify system settings' ki permission chahiye. " +
                "Screen khol di hai, NOVA AI ko allow karein, phir dobara kahein."
        }
        val cr = a.contentResolver
        val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
        val pct = Regex("(\\d{1,3})\\s*(%|percent|fisad|pc|فیصد)").find(raw)?.groupValues?.get(1)?.toIntOrNull()
            ?: Regex("(\\d{1,3})").find(raw)?.value?.toIntOrNull()?.takeIf { it in 1..100 }
        val target = when {
            pct != null -> pct.coerceIn(1, 100) * 255 / 100
            has("full", "max", "maximum", "poori", "puri") -> 255
            has("min", "minimum", "lowest") -> 13
            has("up", "badhao", "barhao", "zyada", "ziada", "increase", "tez") -> cur + 51
            has("down", "kam", "ghatao", "decrease", "dheema") -> cur - 51
            else -> return null
        }.coerceIn(5, 255)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, target)
        return "Boss, brightness ${target * 100 / 255}% kar di."
    }

    // ---------- Volume ----------
    private fun volume(a: Activity, tk: List<String>): String? {
        fun has(vararg w: String) = w.any { it in tk }
        val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when {
            has("up", "badhao", "barhao", "badha", "barha", "zyada", "ziada", "increase", "tez", "high", "اوپر", "بڑھاؤ") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                "Boss, awaaz barha di."
            }
            has("down", "kam", "ghatao", "ghata", "decrease", "dheema", "low", "کم") -> {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                "Boss, awaaz kam kar di."
            }
            else -> null
        }
    }

    // ---------- Media ----------
    private fun media(a: Activity, tk: List<String>): String? {
        fun has(vararg w: String) = w.any { it in tk }
        val (code, msg) = when {
            has("next", "agla", "agle", "اگلا") -> KeyEvent.KEYCODE_MEDIA_NEXT to "Boss, agla gana laga diya."
            has("previous", "pichla", "pichle", "پچھلا") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS to "Boss, pichla gana laga diya."
            has("pause", "roko", "rok", "ruko", "band", "stop", "روکو", "بند") ->
                KeyEvent.KEYCODE_MEDIA_PAUSE to "Boss, music pause kar diya."
            has("play", "chalao", "chala", "resume", "shuru", "چلاؤ") ->
                KeyEvent.KEYCODE_MEDIA_PLAY to "Boss, music chala diya."
            else -> return null
        }
        val am = a.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "$msg (Ye tab chalta hai jab koi music app pehle se khuli ho.)"
    }

    // ---------- Settings ----------
    private fun settings(a: Activity, tk: List<String>): String {
        fun has(vararg w: String) = w.any { it in tk }
        val (action, name) = when {
            has("wifi") || (has("wi") && has("fi")) -> Settings.ACTION_WIFI_SETTINGS to "WiFi settings"
            has("bluetooth") -> Settings.ACTION_BLUETOOTH_SETTINGS to "Bluetooth settings"
            has("display", "brightness", "screen") -> Settings.ACTION_DISPLAY_SETTINGS to "Display settings"
            has("sound") -> Settings.ACTION_SOUND_SETTINGS to "Sound settings"
            has("battery") -> Settings.ACTION_BATTERY_SAVER_SETTINGS to "Battery settings"
            has("location") -> Settings.ACTION_LOCATION_SOURCE_SETTINGS to "Location settings"
            else -> Settings.ACTION_SETTINGS to "Settings"
        }
        a.startActivity(Intent(action))
        return "Boss, $name khol di."
    }

    // ---------- Camera / Contacts ----------
    private fun camera(a: Activity): String {
        a.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        return "Boss, camera khol diya."
    }

    private fun contacts(a: Activity): String {
        a.startActivity(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI))
        return "Boss, contacts khol diye."
    }

    // ---------- Apps ----------
    private val stop = setOf(
        "open", "kholo", "kholen", "khol", "kholiye", "launch", "chalao", "app", "apps",
        "ko", "ka", "ki", "mera", "meri", "mere", "please", "plz", "the", "my", "karo", "kar",
        "do", "de", "dein", "zara", "na", "aur", "and", "کھولو", "کھولیں", "کھول", "ایپ", "کو", "میرا"
    )

    private val aliases = mapOf(
        "gallery" to listOf("gallery", "photos"),
        "photos" to listOf("photos", "gallery"),
        "sms" to listOf("messages", "message"),
        "message" to listOf("messages", "message"),
        "messages" to listOf("messages", "message"),
        "dialer" to listOf("phone", "dialer"),
        "phone" to listOf("phone", "dialer"),
        "yt" to listOf("youtube"),
        "واٹس" to listOf("whatsapp"),
        "یوٹیوب" to listOf("youtube"),
        "کروم" to listOf("chrome"),
        "انسٹاگرام" to listOf("instagram")
    )

    private fun openApp(a: Activity, tk: List<String>): String? {
        val q = tk.filter { it !in stop }
        if (q.isEmpty() || q.size > 2) return null
        val query = q.joinToString(" ")
        val keywords = q.flatMap { aliases[it] ?: listOf(it) }.filter { it.length >= 3 }

        val pm = a.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map {
            it.loadLabel(pm).toString() to it.activityInfo.packageName
        }
        val hit = apps.firstOrNull { (label, _) -> keywords.any { label.lowercase(Locale.ROOT) == it } }
            ?: apps.filter { (label, _) -> keywords.any { label.lowercase(Locale.ROOT).contains(it) } }
                .minByOrNull { it.first.length }

        if (hit == null) return "Boss, '$query' naam ki app nahi mili."
        val launch = pm.getLaunchIntentForPackage(hit.second)
            ?: return "Boss, ${hit.first} khul nahi saki."
        a.startActivity(launch)
        return "Boss, ${hit.first} khol raha hoon."
    }
}
