package com.nova.ai

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Notifications sirf RAM mein rakhta hai (disk par save nahi karta). App band hone par saaf. */
class NovaNotificationService : NotificationListenerService() {

    data class Item(val key: String, val app: String, val title: String, val text: String, val time: Long)

    class ReplyInfo(val title: String, val action: Notification.Action, val time: Long)

    companion object {
        private val items = ArrayList<Item>()
        private val replies = HashMap<String, ReplyInfo>()
        private val WA = setOf("com.whatsapp", "com.whatsapp.w4b")

        @Synchronized
        fun putReply(key: String, r: ReplyInfo) {
            replies[key] = r
            while (replies.size > 30) {
                val oldest = replies.entries.minByOrNull { it.value.time }?.key ?: break
                replies.remove(oldest)
            }
        }

        @Synchronized
        fun removeReply(key: String) {
            replies.remove(key)
        }

        /**
         * WhatsApp ki maujooda notification ke "Reply" se message bhejta hai: WhatsApp khule baghair.
         * Sirf tab jab us contact ki notification abhi maujood ho (naam bilkul wahi ho).
         */
        @Synchronized
        fun reply(ctx: Context, name: String, text: String): Boolean {
            val best = replies.values
                .filter { it.title.trim().equals(name.trim(), ignoreCase = true) }
                .maxByOrNull { it.time } ?: return false
            val ris = best.action.remoteInputs ?: return false
            if (ris.isEmpty()) return false
            return try {
                val intent = Intent()
                val bundle = Bundle()
                for (ri in ris) bundle.putCharSequence(ri.resultKey, text)
                android.app.RemoteInput.addResultsToIntent(ris, intent, bundle)
                best.action.actionIntent.send(ctx, 0, intent)
                true
            } catch (e: Exception) {
                false
            }
        }

        @Synchronized
        fun add(i: Item) {
            items.removeAll { it.key == i.key }
            items.add(0, i)
            while (items.size > 20) items.removeAt(items.size - 1)
        }

        @Synchronized
        fun recent(n: Int): List<Item> = items.take(n)

        @Synchronized
        fun remove(key: String) {
            items.removeAll { it.key == key }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            activeNotifications?.sortedBy { it.postTime }?.forEach { handle(it) }
        } catch (e: Exception) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) handle(sbn)
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        add(Item(sbn.key, app, title.take(40), text.take(100), sbn.postTime))
        if (sbn.packageName in WA) {
            val reply = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
            if (reply != null) putReply(sbn.key, ReplyInfo(title, reply, sbn.postTime))
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn?.key?.let {
            remove(it)
            removeReply(it)
        }
    }
}
