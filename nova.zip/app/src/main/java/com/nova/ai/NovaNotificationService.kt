package com.nova.ai

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Notifications sirf RAM mein rakhta hai (disk par save nahi karta). App band hone par saaf. */
class NovaNotificationService : NotificationListenerService() {

    data class Item(val key: String, val app: String, val title: String, val text: String, val time: Long)

    companion object {
        private val items = ArrayList<Item>()

        @Synchronized
        fun add(i: Item) {
            items.removeAll { it.key == i.key }
            items.add(0, i)
            while (items.size > 20) items.removeAt(items.size - 1)
        }

        @Synchronized
        fun recent(n: Int): List<Item> = items.take(n)

        @Synchronized
        fun remove(key: String) {
            items.removeAll { it.key == key }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: ex.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val app = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }
        add(Item(sbn.key, app, title.take(40), text.take(100), sbn.postTime))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn?.key?.let { remove(it) }
    }
}
