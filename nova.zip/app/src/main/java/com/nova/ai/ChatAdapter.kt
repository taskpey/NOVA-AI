package com.nova.ai

import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Msg(val text: String, val fromUser: Boolean)

class ChatAdapter(private val items: List<Msg>) :
    RecyclerView.Adapter<ChatAdapter.VH>() {

    class VH(root: ViewGroup, val tv: TextView) : RecyclerView.ViewHolder(root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_message, parent, false) as ViewGroup
        return VH(v, v.findViewById(R.id.msgText))
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val m = items[position]
        holder.tv.text = m.text
        holder.tv.setBackgroundResource(
            if (m.fromUser) R.drawable.bubble_user else R.drawable.bubble_nova
        )
        val lp = holder.tv.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (m.fromUser) Gravity.END else Gravity.START
        holder.tv.layoutParams = lp
    }

    override fun getItemCount() = items.size
}
